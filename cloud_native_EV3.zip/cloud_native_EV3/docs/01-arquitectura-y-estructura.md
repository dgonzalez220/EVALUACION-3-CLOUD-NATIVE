# 01 · Arquitectura y Estructura

[← Volver al README](../README.md) · [Componentes y Módulos →](./02-componentes-y-modulos.md)

Este documento describe **dónde está cada cosa** y **cómo se conectan** las piezas del sistema RutaExpress.

---

## 1. Vista general

RutaExpress es una **arquitectura de microservicios** compuesta por:

- Un **frontend SPA** (React) servido por Nginx.
- Un **BFF / API Gateway** (`ms-bff`) que es el único punto de entrada al backend.
- **5 microservicios de dominio**: `shipments`, `catalog`, `audit`, `report`, `notify`.
- **Infraestructura compartida**: PostgreSQL (base de datos relacional única) y RabbitMQ (broker de mensajería).
- **Seguridad externa**: Microsoft Entra ID (Azure AD) como proveedor de identidad.

---

## 2. Árbol de Directorios

```
cloud_native_1-main EV3/
├── README.md                     # Puerta de entrada (este proyecto)
├── docker-compose.yml            # Orquestación de los 10 contenedores
├── deploy.sh                     # Script de despliegue para AWS EC2
├── estructura.txt                # Volcado del árbol de archivos
├── GEMINI.md                     # Nota suelta de stack ("Java Spring Boot + React")
├── docs/                         # Documentación (wiki navegable)
│   ├── AWS_EC2_DEPLOYMENT.md     # Guía de despliegue EC2
│   ├── 01-arquitectura-y-estructura.md
│   ├── 02-componentes-y-modulos.md
│   ├── 03-api-y-flujos-de-datos.md
│   └── 04-herramientas-y-configuracion.md
│
├── frontend-rutaexpress/         # SPA React + Vite + Tailwind (servida por Nginx)
│   ├── src/
│   │   ├── auth/                 # Configuración MSAL (authConfig.js)
│   │   ├── components/           # Componentes reutilizables (dashboard, login, shipments)
│   │   ├── pages/                # Vistas de la aplicación (una por ruta de React Router)
│   │   ├── services/             # Cliente Axios + servicios de API
│   │   ├── assets/               # Imágenes y recursos estáticos
│   │   ├── App.jsx               # Router principal y protección por sesión
│   │   └── main.jsx              # Bootstrap: MSAL + ReactDOM
│   ├── Dockerfile                # Build multi-stage (node → nginx)
│   ├── nginx.conf                # Configuración de Nginx (fallback SPA)
│   ├── .env                      # Variables Vite (API URL + Azure AD)
│   ├── package.json              # Dependencias y scripts del frontend
│   ├── vite.config.js            # Configuración de Vite
│   ├── tailwind.config.js        # Configuración de TailwindCSS
│   └── postcss.config.js         # Pipeline PostCSS/Tailwind
│
├── ms-rutaexpress-bff/           # API Gateway / BFF (Spring Cloud Gateway MVC)
├── ms-rutaexpress-shipments/     # Dominio: Envíos (JPA + RabbitMQ producer)
├── ms-rutaexpress-catalog/       # Dominio: Catálogo / Flota (JPA)
├── ms-rutaexpress-audit/         # Dominio: Auditoría (RabbitMQ consumer + JPA)
├── ms-rutaexpress-notify/        # Dominio: Notificaciones (RabbitMQ producer + consumer + RabbitAdmin)
└── ms-rutaexpress-report/        # Dominio: Reportes (RabbitMQ producer)

# Estructura interna típica de cada microservicio (ejemplo: shipments)
ms-rutaexpress-shipments/
├── pom.xml                       # Dependencias Maven
├── Dockerfile                    # Build multi-stage (maven → JRE)
├── mvnw / mvnw.cmd               # Maven Wrapper
└── src/{main,test}/
    ├── java/cl/duoc/rutaexpress/<dominio>/
    │   ├── config/               # @Configuration (RabbitMQConfig)
    │   ├── controller/           # @RestController (capa HTTP)
    │   ├── dto/                  # Objetos de transferencia (records)
    │   ├── event/                # Modelos de eventos de dominio (records)
    │   ├── model/                # Entidades JPA (@Entity)
    │   ├── repository/           # Repositorios Spring Data
    │   ├── service/              # Lógica de negocio (@Service)
    │   ├── consumer/ / producer/ # (solo ms-audit, ms-notify)
    │   └── <Ms>Application.java  # Punto de entrada de Spring Boot
    └── resources/
        ├── application.properties         # Perfil por defecto
        ├── application-dev.properties     # Perfil local (shipments, audit)
        └── application-docker.properties  # Perfil Docker (perfil activo en compose)
```

### Propósito de cada carpeta principal

| Carpeta | Propósito |
|---|---|
| `frontend-rutaexpress/` | Aplicación de usuario (SPA React). Toda la lógica de UI, autenticación y consumo de API. |
| `ms-rutaexpress-bff/` | Único punto de entrada HTTP. Valida JWT y enruta (`/api/v1/**`) a cada microservicio. No tiene base de datos propia. |
| `ms-rutaexpress-shipments/` | Gestiona envíos. Persiste en PostgreSQL y **publica eventos** de cambio de estado a RabbitMQ. |
| `ms-rutaexpress-catalog/` | Gestiona el catálogo/flota (vehículos, rutas, sucursales) con CRUD y borrado lógico. |
| `ms-rutaexpress-audit/` | **Consume** eventos de cambio de estado y los persiste como log de auditoría inmutable. |
| `ms-rutaexpress-notify/` | Envía notificaciones a una cola y simula el envío (log). Permite crear/eliminar colas vía RabbitAdmin. |
| `ms-rutaexpress-report/` | Genera un identificador de reporte y **publica un evento** a RabbitMQ. |
| `docs/` | Documentación técnica navegable. |

---

## 3. Diagrama de Arquitectura

### 3.1 Vista de despliegue (contenedores)

```mermaid
graph TB
    subgraph Cliente
        U[Usuario / Navegador]
    end

    subgraph "Frontend (Docker)"
        FE["frontend-rutaexpress<br/>React + Nginx :5173→80"]
    end

    subgraph "Backend (Docker)"
        BFF["ms-bff<br/>API Gateway :8080"]
        SHIP["ms-shipments :8085"]
        CAT["ms-catalog :8081"]
        REP["ms-report :8083"]
        AUD["ms-audit :8084"]
        NOT["ms-notify :8082"]
    end

    subgraph "Infraestructura (Docker)"
        DB[("PostgreSQL 16<br/>:5432")]
        MQ{{"RabbitMQ 3<br/>:5672 / :15672"}}
    end

    subgraph "Externo"
        AZ["Microsoft Entra ID<br/>(Azure AD)"]
    end

    U -->|HTTPS| FE
    FE -->|"JWT Bearer /api/v1/**"| BFF
    BFF -->|proxy| SHIP
    BFF -->|proxy| CAT
    BFF -->|proxy| REP
    BFF -->|proxy| AUD
    BFF -->|proxy| NOT

    SHIP -->|JPA| DB
    CAT -->|JPA| DB
    REP -->|JPA| DB
    AUD -->|JPA| DB

    SHIP -->|"publish shipment.status.changed"| MQ
    REP -->|"publish report.generated"| MQ
    NOT -->|"publish notify.key"| MQ
    MQ -->|"consume"| AUD
    MQ -->|"consume"| NOT

    FE -.->|OIDC / MSAL| AZ
    BFF -.->|valida JWKS| AZ
```

### 3.2 Flujo de datos de alto nivel

1. El **navegador** carga la SPA desde Nginx.
2. La SPA obtiene un **token JWT** de Azure AD (MSAL) y lo adjunta en cada petición al BFF (interceptor Axios).
3. El **BFF** valida el token contra las claves JWKS de Azure AD y **enruta** la petición al microservicio correspondiente según el prefijo de ruta.
4. Los microservicios de datos persisten en **PostgreSQL**.
5. `ms-shipments` y `ms-report` **publican eventos** en RabbitMQ; `ms-audit` y `ms-notify` los **consumen** de forma asíncrona y desacoplada.

---

## 4. Patrones de Diseño

La solución combina varios patrones. Se indica dónde encontrar cada capa.

### 4.1 Microservicios por contexto acotado (Bounded Context)
Cada dominio funcional es un servicio independiente y desplegable por separado (`ms-shipments`, `ms-catalog`, etc.). No comparten código; la comunicación entre ellos es **vía HTTP (a través del Gateway)** o **vía eventos (RabbitMQ)**, nunca por llamadas directas entre sí.

### 4.2 API Gateway / Backend For Frontend (BFF)
`ms-bff` actúa como fachada única. La lógica de enrutamiento está en las rutas declaradas en [application.properties](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-bff/src/main/resources/application.properties) y la configuración de seguridad en [SecurityConfig.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-bff/src/main/java/cl/duoc/rutaexpress/bff/security/SecurityConfig.java).

### 4.3 Arquitectura en capas (Layered) dentro de cada microservicio
Cada servicio de dominio sigue el patrón **Controller → Service → Repository → Entity**:

| Capa | Paquete | Responsabilidad |
|---|---|---|
| Presentación | `controller/` | Recibe HTTP, valida y delega. |
| Negocio | `service/` | Reglas de negocio y publicación de eventos. |
| Persistencia | `repository/` | Acceso a datos (Spring Data JPA). |
| Dominio | `model/` | Entidades JPA y reglas locales (`@PrePersist`). |
| Transporte | `dto/`, `event/` | Contratos de entrada/salida (records). |

### 4.4 Arquitectura orientada a eventos (Event-Driven / Pub-Sub)
Se usa el patrón **Publish/Subscribe** sobre **Topic Exchanges** de RabbitMQ:
- `ms-shipments` **publica** `shipment.status.changed` → lo **consume** `ms-audit`.
- `ms-report` **publica** `report.generated`.
- `ms-notify` **publica/consume** en `notification-exchange` → `notification-queue`.

Esto desacopla productores y consumidores en tiempo y espacio. Ver topología exacta en [03-api-y-flujos-de-datos.md](./03-api-y-flujos-de-datos.md).

### 4.5 DTO y Value Objects inmutables
Los contratos de transporte usan **`record` de Java** (`UpdateShipmentStatusDTO`, `ShipmentStatusEvent`) para garantizar inmutabilidad y reducir boilerplate.

### 4.6 Resource Server (OAuth2/JWT)
El backend no emite tokens: **valida** los emitidos por Azure AD como *OAuth2 Resource Server* ([JwtDecoderConfig.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-bff/src/main/java/cl/duoc/rutaexpress/bff/security/JwtDecoderConfig.java)). La SPA actúa como cliente público con **Authorization Code Flow + PKCE** (gestionado por MSAL).

### 4.7 Graceful Degradation / Persistencia local (frontend)
El frontend aplica **actualización optimista** de la UI y **fallback a `localStorage`** cuando el backend no responde (p. ej. en [ShipmentsPage.jsx](file:///home/danko/Descargas/cloud_native_1-main%20EV3/frontend-rutaexpress/src/pages/ShipmentsPage.jsx) y [FleetPage.jsx](file:///home/danko/Descargas/cloud_native_1-main%20EV3/frontend-rutaexpress/src/pages/FleetPage.jsx)), mostrando un aviso de "Modo Offline / Caché Local".

### 4.8 Soft Delete (borrado lógico)
`ms-catalog` no elimina registros físicamente: marca `active = false` ([CatalogController.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-catalog/src/main/java/cl/duoc/rutaexpress/catalog/controller/CatalogController.java)).

### 4.9 Build multi-stage (Docker)
Todos los servicios y el frontend usan Dockerfiles multi-stage para separar compilación de ejecución y reducir el tamaño de la imagen final.

---

## 5. Mapa de puertos y redes

Todos los contenedores se comunican en la **red interna de Docker** por su nombre de servicio (p. ej. `http://ms-shipments:8085`, `postgres-db:5432`). Solo el frontend (5173), el BFF (8080) y los puertos de infraestructura (5432, 5672, 15672) se publican al host.

| Contenedor | Puerto host | URL interna |
|---|---|---|
| `frontend-rutaexpress` | 5173 | `:80` (Nginx) |
| `ms-bff` | 8080 | `http://ms-bff:8080` |
| `ms-catalog` | 8081 | `http://ms-catalog:8081` |
| `ms-notify` | 8082 | `http://ms-notify:8082` |
| `ms-report` | 8083 | `http://ms-report:8083` |
| `ms-audit` | 8084 | `http://ms-audit:8084` |
| `ms-shipments` | 8085 | `http://ms-shipments:8085` |
| `postgres-db` | 5432 | `postgres-db:5432` |
| `rabbitmq` | 5672 / 15672 | `rabbitmq:5672` |

---

## ⚠️ Notas Técnicas / Deuda Técnica

- **Base de datos compartida:** los 4 microservicios con persistencia (`shipments`, `catalog`, `audit`, `report`) apuntan a la **misma base `rutaexpress`** en el perfil Docker. En microservicios estrictos cada servicio debería tener su propio esquema/base; aquí hay acoplamiento a nivel de datos.
- **Colas de auditoría duplicadas:** `ms-shipments` declara la cola `audit.shipment.queue` (routing key `shipment.status.changed`) y `ms-audit` declara `shipment.audit.queue` (routing key `shipment.status.#`). Ambos se enlazan al mismo exchange `shipment.exchange`, por lo que se crean **dos colas** que reciben el mismo evento. Funciona, pero es redundante.
- **Configuración por defecto inconsistente:** [application.properties](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-report/src/main/resources/application.properties) de `ms-report` y `ms-audit` usa la base `rutaexpress_db` (que **no existe**; el contenedor crea `rutaexpress`) y credenciales RabbitMQ `guest/guest`. El perfil `docker` sobrescribe esto, por lo que solo es un riesgo si se ejecuta sin el perfil `docker`.
- **Perfil `dev` de auditoría inconsistente:** [application-dev.properties](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-audit/src/main/resources/application-dev.properties) apunta a **Oracle** (`jdbc:oracle:thin:@localhost:1521/FREEPDB1`) con dialecto Oracle, pero el `pom.xml` **no incluye el driver de Oracle**. Es remanente de una versión anterior.
- **Archivo/clase desalineados:** [AuditKafkaConsumer.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-audit/src/main/java/cl/duoc/rutaexpress/audit/consumer/AuditKafkaConsumer.java) declara `public class AuditRabbitConsumer` → **error de compilación** en Java. Debe renombrarse el archivo o la clase.
