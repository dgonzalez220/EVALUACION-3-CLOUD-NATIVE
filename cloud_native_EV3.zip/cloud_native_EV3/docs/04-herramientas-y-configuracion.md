# 04 · Herramientas y Configuración

[← API y Flujos](./03-api-y-flujos-de-datos.md) · [Volver al README](../README.md)

Este documento recoge las **dependencias externas**, las **variables de entorno**, los **comandos útiles** y la **deuda técnica** del proyecto.

---

## 1. Dependencias Externas

### 1.1 Frontend (`frontend-rutaexpress/package.json`)

| Dependencia | Versión | ¿Para qué? |
|---|---|---|
| `react` / `react-dom` | ^19.2.8 | Librería base de UI. |
| `react-router-dom` | ^7.18.3 | Enrutado SPA y navegación entre páginas. |
| `@azure/msal-browser` | ^5.21.0 | Cliente MSAL: login, tokens y sesión contra Azure AD. |
| `@azure/msal-react` | ^5.7.0 | Integración de MSAL con React (`MsalProvider`, `useMsal`). |
| `axios` | ^1.20.0 | Cliente HTTP con interceptores (inyección del JWT). |
| `lucide-react` | ^1.47.0 | Set de iconos. |
| `vite` | ^8.3.0 (dev) | Bundler y servidor de desarrollo. |
| `@vitejs/plugin-react` | ^6.1.1 (dev) | Soporte de React (Fast Refresh, JSX). |
| `tailwindcss` + `@tailwindcss/postcss` | ^4.3.3 (dev) | Framework de utilidades CSS. |
| `autoprefixer` / `postcss` | ^10 / ^8 (dev) | Pipeline de PostCSS requerido por Tailwind. |
| `oxlint` | ^1.81.0 (dev) | Linter rápido (Rust). |
| `@types/react`, `@types/react-dom` | ^19 (dev) | Tipos de React (para tooling). |

### 1.2 Backend (dependencias Maven comunes)

Presentes en los `pom.xml` (Spring Boot 3.2.5, Java 21):

| Dependencia | Presente en | ¿Para qué? |
|---|---|---|
| `spring-boot-starter-web` | todos | API REST / MVC. |
| `spring-boot-starter-data-jpa` | shipments, catalog, audit, report | Persistencia ORM con Hibernate. |
| `postgresql` (driver) | shipments, catalog, audit, report | Conexión JDBC a PostgreSQL. |
| `spring-boot-starter-amqp` | shipments, notify, report, audit | Soporte RabbitMQ (Spring AMQP). |
| `spring-boot-starter-json` | shipments | Serialización JSON de mensajes. |
| `spring-boot-starter-validation` | notify | Validaciones (`@Valid`, `@NotBlank`, `@Pattern`). |
| `jackson-databind` + `jackson-datatype-jsr310` | audit | Serialización de `LocalDateTime` en eventos. |
| `spring-boot-starter-oauth2-resource-server` | bff | Validación de JWT (Resource Server). |
| `spring-boot-starter-security` | bff | Cadena de filtros de seguridad y CORS. |
| `spring-cloud-starter-gateway-mvc` | bff | Enrutamiento del API Gateway (WebMVC). |
| `lombok` | shipments, catalog, notify, report, audit | Reducción de boilerplate (`@Data`, `@Slf4j`). |
| `spring-boot-starter-test` / `spring-rabbit-test` / `spring-security-test` | varios (test) | Pruebas unitarias e de integración. |

### 1.3 Infraestructura (imágenes Docker)

| Imagen | Uso |
|---|---|
| `postgres:16-alpine` | Base de datos relacional. |
| `rabbitmq:3-management` | Broker de mensajería + consola de administración. |
| `maven:3.9.6-eclipse-temurin-21-alpine` | Stage de compilación de microservicios. |
| `eclipse-temurin:21-jre-alpine` | Runtime de los microservicios. |
| `node:20-alpine` | Stage de build del frontend. |
| `nginx:alpine` | Servidor estático del frontend. |

---

## 2. Variables de Entorno

### 2.1 Frontend (`frontend-rutaexpress/.env`)

| Variable | ¿Obligatoria? | Ejemplo | Descripción |
|---|---|---|---|
| `VITE_API_URL` | Sí | `http://localhost:8080` | URL base del BFF. Si falta, el código usa `window.location.hostname:8080`. |
| `VITE_AZURE_CLIENT_ID` | Sí | `8e9ad887-…` | Client ID de la app en Azure AD. |
| `VITE_AZURE_TENANT_ID` | Sí | `7ecd33b8-…` | Tenant (directorio) de Azure AD. |
| `VITE_AZURE_REDIRECT_URI` | Sí | `http://localhost:5173` | URI de redirección tras login. |

### 2.2 Backend (`docker-compose.yml` inyecta estas variables)

| Variable | Servicio(s) | ¿Obligatoria? | Ejemplo | Descripción |
|---|---|---|---|---|
| `SPRING_PROFILES_ACTIVE` | todos los backends | Sí (compose) | `docker` | Activa `application-docker.properties`. |
| `MS_SHIPMENTS_URL` | bff | Sí | `http://ms-shipments:8085` | URI de destino de la ruta `/api/v1/shipments/**`. |
| `MS_CATALOG_URL` | bff | Sí | `http://ms-catalog:8081` | URI de destino de `/api/v1/catalog/**`. |
| `MS_NOTIFY_URL` | bff | Sí | `http://ms-notify:8082` | URI de destino de `/api/v1/notify/**`. |
| `MS_REPORT_URL` | bff | Sí | `http://ms-report:8083` | URI de destino de `/api/v1/report/**`. |
| `MS_AUDIT_URL` | bff | Sí | `http://ms-audit:8084` | URI de destino de `/api/v1/audit/**`. |
| `FRONTEND_URL` | bff | No | `http://localhost:5173` | Origen permitido en CORS. |
| `SPRING_DATASOURCE_URL` | shipments, catalog, report, audit | Sí | `jdbc:postgresql://postgres-db:5432/rutaexpress` | URL JDBC. |
| `SPRING_DATASOURCE_USERNAME` | idem | Sí | `postgres` | Usuario DB. |
| `SPRING_DATASOURCE_PASSWORD` | idem | Sí | `admin123` | Contraseña DB. |
| `SPRING_RABBITMQ_HOST` | shipments, notify, report, audit | Sí | `rabbitmq` | Host del broker. |
| `SPRING_RABBITMQ_USERNAME` / `SPRING_RABBITMQ_PASSWORD` | idem | Sí | `user` / `password` | Credenciales del broker. |
| `POSTGRES_DB` / `POSTGRES_USER` / `POSTGRES_PASSWORD` | postgres-db | Sí | `rutaexpress` / `postgres` / `admin123` | Inicialización de PostgreSQL. |
| `RABBITMQ_DEFAULT_USER` / `RABBITMQ_DEFAULT_PASS` | rabbitmq | Sí | `user` / `password` | Credenciales del broker. |

> **Nota:** el BFF fija el `jwk-set-uri` y la `audience` de Azure AD **directamente en `application.properties`** (no como variables de entorno).

### 2.3 Escenarios de ejecución

| Escenario | Perfil | Datasource |
|---|---|---|
| Docker (`SPRING_PROFILES_ACTIVE=docker`) | `docker` | `postgres-db:5432/rutaexpress`, RabbitMQ `user/password` |
| Local sin Docker (shipments/audit) | `dev` | `localhost:5432` (audit: **Oracle**, ver deuda) |
| Por defecto (sin perfil) | — | según `application.properties` (report/audit usan `rutaexpress_db` + `guest/guest`) |

---

## 3. Scripts y Comandos

### 3.1 Frontend (desde `frontend-rutaexpress/`)

```bash
npm install       # Instala dependencias
npm run dev       # Servidor de desarrollo Vite en http://localhost:5173
npm run build     # Build de producción (dist/)
npm run preview   # Previsualiza el build de producción
npm run lint      # Ejecuta oxlint
```

### 3.2 Backend (desde cada microservicio)

```bash
./mvnw clean package            # Compila y empaqueta (genera target/*.jar)
./mvnw spring-boot:run          # Ejecuta el servicio en local
./mvnw test                     # Ejecuta las pruebas
./mvnw -DskipTests package      # Empaqueta sin pruebas (uso en Docker)
```

### 3.3 Orquestación (desde la raíz)

```bash
docker compose up -d --build    # Levanta todo el stack
docker compose down             # Detiene y elimina los contenedores
docker compose logs -f ms-bff   # Logs de un servicio concreto
./deploy.sh                     # Despliegue automatizado (instala Docker y levanta)
```

### 3.4 Verificación rápida (smoke tests)

```bash
curl http://localhost:8080/api/v1/test          # BFF vivo
curl http://localhost:8085/api/v1/shipments     # ms-shipments (directo)
curl http://localhost:8081/api/v1/catalog       # ms-catalog
curl "http://localhost:8083/api/v1/report/generate?type=PDF"   # ms-report (POST)
curl http://localhost:8084/api/v1/audit/shipments/all          # ms-audit
curl http://localhost:8082/api/v1/notify        # ms-notify
```

---

## 4. Conexión a la infraestructura

| Servicio | Acceso |
|---|---|
| RabbitMQ Console | http://localhost:15672 — usuario `user`, contraseña `password`. |
| PostgreSQL | `psql -h localhost -p 5432 -U postgres -d rutaexpress` (password `admin123`). |

---

## ⚠️ Notas Técnicas / Deuda Técnica

- **Script de pruebas frontend inexistente:** [api.test.js](file:///home/danko/Descargas/cloud_native_1-main%20EV3/frontend-rutaexpress/src/services/api.test.js) importa **`vitest`**, pero `vitest` **no está declarado** en `package.json` y **no existe script `test`**. El [README del frontend](file:///home/danko/Descargas/cloud_native_1-main%20EV3/frontend-rutaexpress/README.md) menciona `npm test`, que **fallará**. Falta añadir `vitest` y `"test": "vitest"`.
- **Credenciales y IDs reales versionados:** el archivo [.env](file:///home/danko/Descargas/cloud_native_1-main%20EV3/frontend-rutaexpress/.env) incluye el `client_id`, `tenant_id` y una URL de API reales. No debería versionarse; usar `.env.example`. Igualmente, `docker-compose.yml` contiene credenciales en texto plano (`admin123`, `user/password`).
- **`docker-compose` (v1) en `deploy.sh`:** el script usa `docker-compose` en lugar de `docker compose` (plugin v2). En instalaciones modernas puede no existir.
- **Variables de compilación del frontend:** `VITE_API_URL` se "hornea" en el build. En `docker-compose.yml` el contenedor del frontend se construye sin fijar `VITE_API_URL` de producción, por lo que heredará el valor del `.env` (`localhost:8080`). En EC2 el navegador apuntaría a su propio `localhost`, no a la IP del servidor.
- **Perfil `dev` de auditoría apunta a Oracle** sin driver en el `pom.xml` (ver [01-arquitectura](./01-arquitectura-y-estructura.md)).
- **`application.properties` de report/audit** usan `rutaexpress_db` y `guest/guest` (inconsistentes con `docker-compose`); solo funcionan correctamente con el perfil `docker`.
- **Sin tests en la mayoría de microservicios:** solo existen pruebas `contextLoads` autogeneradas y una prueba real en `ms-report` ([ReportGeneratorServiceTest](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-report/src/test/java/cl/duoc/rutaexpress/report/service/ReportGeneratorServiceTest.java)).
- **Desalineación de configuración del broker:** `ms-report` y `ms-audit` leen `SPRING_RABBITMQ_USER`, mientras el resto usa `SPRING_RABBITMQ_USERNAME`; `docker-compose` provee `SPRING_RABBITMQ_USERNAME`, por lo que en report/audit se cae al valor por defecto del perfil `docker` (`user`).
