# 03 · API y Flujos de Datos

[← Componentes](./02-componentes-y-modulos.md) · [Volver al README](../README.md) · [Herramientas →](./04-herramientas-y-configuracion.md)

Todas las rutas se exponen a través del **BFF (puerto 8080)**, que enruta por prefijo hacia cada microservicio. En los puertos propios de cada servicio, la ruta es idéntica.

> **Autenticación:** las peticiones del frontend incluyen `Authorization: Bearer <JWT>` (inyectado por el interceptor de Axios). El BFF valida el token contra Azure AD. Nota: la política de seguridad actual permite el acceso a todas las rutas (ver deuda técnica).

---

## 1. Tabla de Endpoints

### 1.1 BFF / API Gateway · `:8080`

| Método | Ruta | Descripción | Parámetros | Respuesta (ejemplo) |
|---|---|---|---|---|
| `GET` | `/api/v1/test` | Diagnóstico E2E. Devuelve estado y datos del usuario autenticado si hay JWT. | — (JWT opcional) | `{"status":"UP","message":"Conexión E2E exitosa con ms-rutaexpress-bff","timestamp":"2026-11-20T12:00:00Z","authenticatedUser":{"subject":"…","username":"user@dominio.cl","name":"…","scp":"…"}}` |
| `GET` | `/api/bff/shipments` | **Legacy.** Indica usar `/api/v1/shipments`. | — | `["Envío RE00123 - Este endpoint es legacy...","Autenticado como: …"]` |
| `GET/POST/PATCH` | `/api/v1/shipments/**` | **Proxy** → `ms-shipments:8085` | según destino | ver 1.2 |
| `GET/POST/PUT/DELETE` | `/api/v1/catalog/**` | **Proxy** → `ms-catalog:8081` | según destino | ver 1.3 |
| `GET/POST` | `/api/v1/report/**` | **Proxy** → `ms-report:8083` | según destino | ver 1.4 |
| `GET` | `/api/v1/audit/**` | **Proxy** → `ms-audit:8084` | según destino | ver 1.5 |
| `GET/POST/DELETE` | `/api/v1/notify/**` | **Proxy** → `ms-notify:8082` | según destino | ver 1.6 |

### 1.2 `ms-rutaexpress-shipments` (`:8085`)

| Método | Ruta | Descripción | Parámetros | Respuesta (ejemplo) |
|---|---|---|---|---|
| `GET` | `/api/v1/shipments` | Lista todos los envíos. | — | `[{"id":5,"trackingCode":"RE-100238","recipientName":"Farmacias Unidas","origin":"Bodega La Serena","destination":"Calle Balmaceda 310","status":"Creado","createdAt":"2026-10-17T12:00:00"}]` |
| `POST` | `/api/v1/shipments` | Crea un envío. | Body: `{trackingCode, recipientName, origin, destination, status}` (opcional; se autocompletan) | `201 Created` con la entidad guardada. |
| `PATCH` | `/api/v1/shipments/{id}/status` | Actualiza el estado y **publica el evento** de auditoría. | Path: `id`; Body: `{"status":"En Ruta","location":"Ruta 68","user":"despachador@x.cl"}` | `{"id":5,"trackingCode":"RE-100238","status":"En Ruta", …}` |

### 1.3 `ms-rutaexpress-catalog` (`:8081`)

| Método | Ruta | Descripción | Parámetros | Respuesta (ejemplo) |
|---|---|---|---|---|
| `GET` | `/api/v1/catalog` | Lista ítems **activos**. | — | `[{"id":1,"name":"BPGK-12 - Volvo FH 460","description":"Conductor: Ana M.","category":"TRUCK","active":true}]` |
| `GET` | `/api/v1/catalog/{id}` | Obtiene un ítem. | Path: `id` | el ítem o `404`. |
| `GET` | `/api/v1/catalog/category/{category}` | Lista por categoría (ej. `TRUCK`). | Path: `category` | lista de ítems. |
| `POST` | `/api/v1/catalog` | Crea un ítem (`active=true`). | Body: `{name, description, category}` | `201 Created` + ítem. |
| `PUT` | `/api/v1/catalog/{id}` | Actualiza `name/description/category`. | Path: `id`; Body del ítem | ítem actualizado o `404`. |
| `DELETE` | `/api/v1/catalog/{id}` | **Soft delete** (`active=false`). | Path: `id` | `204 No Content` o `404`. |

### 1.4 `ms-rutaexpress-report` (`:8083`)

| Método | Ruta | Descripción | Parámetros | Respuesta (ejemplo) |
|---|---|---|---|---|
| `GET` | `/api/v1/report` | Health/estado del servicio. | — | `Report service is running` |
| `POST` | `/api/v1/report/generate` | Genera un `reportId` y publica evento a RabbitMQ. | Query: `type` (default `PDF`) | `{"message":"Generación de reporte iniciada","reportId":"b3f…uuid","type":"PDF"}` |

### 1.5 `ms-rutaexpress-audit` (`:8084`)

| Método | Ruta | Descripción | Parámetros | Respuesta (ejemplo) |
|---|---|---|---|---|
| `GET` | `/api/v1/audit/shipments` · `/all` | Todos los registros de auditoría. | — | `[{"id":1,"shipmentId":5,"previousStatus":"Creado","newStatus":"En Ruta","location":"Ruta 68","user":"despachador@x.cl","timestamp":"2026-10-17T14:30:00"}]` |
| `GET` | `/api/v1/audit/shipments/{shipmentId}` | Historial de un envío (desc por timestamp). | Path: `shipmentId` (solo dígitos) | lista filtrada. |

### 1.6 `ms-rutaexpress-notify` (`:8082`)

| Método | Ruta | Descripción | Parámetros | Respuesta (ejemplo) |
|---|---|---|---|---|
| `GET` | `/api/v1/notify` | Health/estado. | — | `Notify service is running` |
| `POST` | `/api/v1/notify/send` | Encola una notificación (producer). | Body: `{recipient, subject, body}` | `Notificación enviada a la cola de RabbitMQ exitosamente.` |
| `POST` | `/api/v1/notify/queues` | Crea una cola vía RabbitAdmin. | Body: `{name, durable}` | `{"message":"Cola creada exitosamente: mi-cola"}` |
| `DELETE` | `/api/v1/notify/queues/{name}` | Elimina una cola. | Path: `name` | `{"message":"Cola eliminada exitosamente: mi-cola"}` |

---

## 2. Topología de Mensajería (RabbitMQ)

| Exchange (Topic) | Routing Key | Cola(s) | Productor | Consumidor |
|---|---|---|---|---|
| `shipment.exchange` | `shipment.status.changed` | `audit.shipment.queue` (declarada por shipments) | `ms-shipments` | — |
| `shipment.exchange` | `shipment.status.#` | `shipment.audit.queue` (declarada por audit) | `ms-shipments` | `ms-audit` |
| `report.exchange` | `report.generated` | `report.queue` | `ms-report` | — (sin consumidor) |
| `notification-exchange` | `notify.key` | `notification-queue` | `ms-notify` | `ms-notify` |

---

## 3. Flujos Críticos

### 3.1 Autenticación (Azure AD / MSAL → BFF)

```mermaid
sequenceDiagram
    participant U as Usuario
    participant FE as Frontend (MSAL)
    participant AZ as Microsoft Entra ID
    participant BFF as ms-bff

    U->>FE: Click "Iniciar sesión con Microsoft"
    FE->>AZ: loginRedirect (Authorization Code + PKCE)
    AZ-->>FE: Código de autorización
    FE->>AZ: Canje por tokens (access/id/refresh)
    AZ-->>FE: Tokens (access token con scope api://…/read)
    FE->>FE: setActiveAccount + getter de token (acquireTokenSilent)
    U->>FE: Navega a una vista (ej. /shipments)
    FE->>BFF: GET /api/v1/shipments (Authorization: Bearer <token>)
    BFF->>AZ: Valida firma contra JWKS
    AZ-->>BFF: Claves públicas (JWKS)
    BFF->>BFF: Valida exp/iat (60 min de skew)
    BFF-->>FE: 200 OK (datos)
```

### 3.2 Actualización de estado de envío → Auditoría (event-driven)

```mermaid
sequenceDiagram
    participant U as Usuario
    participant FE as ShipmentsPage
    participant BFF as ms-bff
    participant SH as ms-shipments
    participant DB as PostgreSQL
    participant MQ as RabbitMQ
    participant AU as ms-audit

    U->>FE: Cambia estado en el <select>
    FE->>FE: Actualiza UI (optimista) + localStorage
    FE->>BFF: PATCH /api/v1/shipments/5/status {status:"En Ruta", location, user}
    BFF->>SH: proxy → /api/v1/shipments/5/status
    SH->>DB: UPDATE shipments SET status='En Ruta'
    SH->>MQ: publish shipment.exchange / shipment.status.changed
    SH-->>BFF: 200 (entidad actualizada)
    BFF-->>FE: 200 OK
    FE->>BFF: GET /api/v1/shipments (refresco)
    MQ->>AU: enruta a shipment.audit.queue
    AU->>DB: INSERT shipment_audit (log inmutable)
    Note over FE,AU: El timeline se consulta luego vía GET /api/v1/audit/shipments/5
```

### 3.3 Creación de envío

```mermaid
sequenceDiagram
    participant FE as ShipmentsPage
    participant BFF as ms-bff
    participant SH as ms-shipments

    FE->>FE: Guardado optimista + tracking local (RE-xxxx)
    FE->>BFF: POST /api/v1/shipments {trackingCode, recipientName, origin, destination, status:"Creado"}
    BFF->>SH: proxy
    SH->>SH: @PrePersist autocompleta tracking/status si faltan
    SH-->>BFF: 201 Created
    BFF-->>FE: 201
    FE->>BFF: GET /api/v1/shipments (refresco)
    Note over FE: Si el backend falla, queda en localStorage (modo offline)
```

### 3.4 Generación de reporte

```mermaid
sequenceDiagram
    participant FE as ReportsPage
    participant BFF as ms-bff
    participant RE as ms-report
    participant MQ as RabbitMQ

    FE->>BFF: POST /api/v1/report/generate?type=PDF
    BFF->>RE: proxy
    RE->>RE: generateReport(type) → UUID
    RE->>MQ: publish report.exchange / report.generated
    RE-->>BFF: {message, reportId, type}
    BFF-->>FE: 200 OK
    FE->>FE: Muestra confirmación con reportId
```

### 3.5 Notificación asíncrona (producer → consumer)

```mermaid
sequenceDiagram
    participant C as Cliente
    participant BFF as ms-bff
    participant NO as ms-notify
    participant MQ as RabbitMQ

    C->>BFF: POST /api/v1/notify/send {recipient, subject, body}
    BFF->>NO: proxy
    NO->>MQ: publish notification-exchange / notify.key
    MQ->>NO: enruta a notification-queue
    NO->>NO: consumer loguea "envío" y hace basicAck
    NO-->>BFF: "Notificación enviada …"
    BFF-->>C: 200 OK
```

### 3.6 Carga del Dashboard

1. `DashboardPage` llama a `GET /api/v1/test` → muestra badge de conexión E2E (o aviso "operando en modo local").
2. Llama a `getShipments()` → `GET /api/v1/shipments`.
3. Renderiza `KpiCards` (total), `FlowCard` (etapas) y `ShipmentTable` (últimos envíos).

---

## ⚠️ Notas Técnicas / Deuda Técnica

- **Seguridad permisiva:** en [SecurityConfig.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-bff/src/main/java/cl/duoc/rutaexpress/bff/security/SecurityConfig.java) todas las rutas usan `permitAll()` (incluido `/api/v1/**`), por lo que **la validación de token no bloquea el acceso**. El `JwtAuthenticationConverter` y la validación JWKS existen, pero el sistema no está realmente protegido.
- **Validación de audiencia ausente:** [JwtDecoderConfig.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-bff/src/main/java/cl/duoc/rutaexpress/bff/security/JwtDecoderConfig.java) configura un validador que **solo valida timestamps**; aunque `audiences` está declarado en `application.properties`, no se aplica `JwtClaimValidator`/`JwtIssuerValidator` para audiencia/emisor.
- **Cola huérfana:** `report.exchange` → `report.queue` no tienen consumidor; el evento de reporte se descarta silenciosamente.
- **Colas de auditoría duplicadas:** ver nota en [01-arquitectura-y-estructura.md](./01-arquitectura-y-estructura.md) (se declaran `audit.shipment.queue` y `shipment.audit.queue`).
- **`GET /api/v1/test` sin JWT:** devuelve `status: UP` sin la sección `authenticatedUser`, lo que el dashboard interpreta como conexión exitosa.
- **Timestamps en zona del servidor:** entidades y eventos usan `LocalDateTime.now()` (sin zona horaria explícita).
