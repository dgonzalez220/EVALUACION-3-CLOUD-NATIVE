# 02 · Componentes y Módulos

[← Arquitectura](./01-arquitectura-y-estructura.md) · [Volver al README](../README.md) · [API y Flujos →](./03-api-y-flujos-de-datos.md)

Desglose de cada módulo/servicio/componente: **ruta**, **responsabilidad**, **elementos clave** y **dependencias internas**.

---

## 1. Frontend — `frontend-rutaexpress/`

SPA React que consume el BFF. Estructura: `main.jsx` (bootstrap) → `App.jsx` (router) → `pages/` → `components/`, con `services/` para la API.

### 1.1 Bootstrap y enrutado

| Ruta | Responsabilidad | Elementos clave | Dependencias |
|---|---|---|---|
| [src/main.jsx](file:///home/danko/Descargas/cloud_native_1-main%20EV3/frontend-rutaexpress/src/main.jsx) | Punto de entrada. Inicializa MSAL, procesa redirects de login, registra el *token getter* de Axios y monta React. | `msalInstance` (`PublicClientApplication`), `setAuthTokenGetter` (token silencioso con `acquireTokenSilent`), `MsalProvider`, `ReactDOM.createRoot`. | `auth/authConfig`, `services/api` |
| [src/App.jsx](file:///home/danko/Descargas/cloud_native_1-main%20EV3/frontend-rutaexpress/src/App.jsx) | Define el router y protege rutas según `accounts.length`. Registra el getter de token cuando hay sesión. | `BrowserRouter`, `<Routes>` condicionales, `setAuthTokenGetter`, `bffTokenRequest`. | `react-router-dom`, `@azure/msal-react`, todas las `pages/`, `DashboardLayout` |
| [src/index.css](file:///home/danko/Descargas/cloud_native_1-main%20EV3/frontend-rutaexpress/src/index.css) | Importa Tailwind y estilos globales (`body`). | `@import "tailwindcss"`. | TailwindCSS |

### 1.2 Autenticación

| Ruta | Responsabilidad | Elementos clave |
|---|---|---|
| [src/auth/authConfig.js](file:///home/danko/Descargas/cloud_native_1-main%20EV3/frontend-rutaexpress/src/auth/authConfig.js) | Configuración de MSAL y scopes. | `msalConfig` (clientId, authority/tenant, redirectUri, `cacheLocation: sessionStorage`), `loginRequest` (`openid`, `profile`, `User.Read`), `bffTokenRequest` (`api://…/read`). |

### 1.3 Servicios de API

| Ruta | Responsabilidad | Elementos clave |
|---|---|---|
| [src/services/api.js](file:///home/danko/Descargas/cloud_native_1-main%20EV3/frontend-rutaexpress/src/services/api.js) | Cliente Axios central. Calcula `baseURL`, inyecta el token JWT y maneja 401/403. | `getApiBaseUrl()`, `setAuthTokenGetter()`, interceptores de request (añade `Authorization: Bearer`) y response (warning 401/403). |
| [src/services/shipmentService.js](file:///home/danko/Descargas/cloud_native_1-main%20EV3/frontend-rutaexpress/src/services/shipmentService.js) | Operaciones sobre envíos. | `getShipments()`, `createShipment()`, `updateShipmentStatus()`, `getShipmentHistory()` (devuelve `[]` ante error). |
| [src/services/testService.js](file:///home/danko/Descargas/cloud_native_1-main%20EV3/frontend-rutaexpress/src/services/testService.js) | Prueba de conectividad E2E con el BFF. | `verifyBffConnection()` → `GET /api/v1/test`. |
| [src/services/api.test.js](file:///home/danko/Descargas/cloud_native_1-main%20EV3/frontend-rutaexpress/src/services/api.test.js) | Test unitario del cliente Axios. | `describe`/`it` de Vitest; verifica que `api` y `baseURL` existen. |

### 1.4 Páginas

| Ruta | Responsabilidad | Elementos clave | Dependencias internas |
|---|---|---|---|
| [pages/LoginPage.jsx](file:///home/danko/Descargas/cloud_native_1-main%20EV3/frontend-rutaexpress/src/pages/LoginPage.jsx) | Pantalla de login (layout 2 columnas). | `handleLogin()` → `instance.loginRedirect(loginRequest)`. | `login/*`, `authConfig` |
| [pages/DashboardPage.jsx](file:///home/danko/Descargas/cloud_native_1-main%20EV3/frontend-rutaexpress/src/pages/DashboardPage.jsx) | Panel principal: prueba conexión BFF y carga envíos; atajos a módulos. | `useEffect` con `api.get('/api/v1/test')` y `getShipments()`; renderiza `KpiCards`, `FlowCard`, `ShipmentTable`. | `KpiCards`, `FlowCard`, `ShipmentTable`, `shipmentService`, `api` |
| [pages/ShipmentsPage.jsx](file:///home/danko/Descargas/cloud_native_1-main%20EV3/frontend-rutaexpress/src/pages/ShipmentsPage.jsx) | Gestión de envíos: listar, crear, cambiar estado, ver timeline. | `fetchShipments()`, `handleCreateShipment()` (optimista + `localStorage`), `handleStatusChange()` (optimista + `PATCH`). Modo offline. | `ShipmentTable`, `CreateShipmentModal`, `TimelineModal`, `shipmentService` |
| [pages/FleetPage.jsx](file:///home/danko/Descargas/cloud_native_1-main%20EV3/frontend-rutaexpress/src/pages/FleetPage.jsx) | Flota de camiones: KPIs, filtros, búsqueda, alta y cambio de estado. | `handleCreateTruck()`, `handleStatusChange()`, persistencia en `localStorage` y `POST /api/v1/catalog`. | `api`, `lucide-react` |
| [pages/ReportsPage.jsx](file:///home/danko/Descargas/cloud_native_1-main%20EV3/frontend-rutaexpress/src/pages/ReportsPage.jsx) | Solicita generación de reportes e historial (mock). | `handleGenerate()` → `POST /api/v1/report/generate?type=…`. | `api` |
| [pages/AuditPage.jsx](file:///home/danko/Descargas/cloud_native_1-main%20EV3/frontend-rutaexpress/src/pages/AuditPage.jsx) | Log de auditoría con búsqueda. | `useEffect` → `GET /api/v1/audit/shipments/all` con fallback demo. | `api` |
| [pages/SettingsPage.jsx](file:///home/danko/Descargas/cloud_native_1-main%20EV3/frontend-rutaexpress/src/pages/SettingsPage.jsx) | Preferencias e info del sistema (estado de servicios y toggles). | `Toggle`, `serviceStatus`, `handleSave()`. | — |
| [pages/HelpPage.jsx](file:///home/danko/Descargas/cloud_native_1-main%20EV3/frontend-rutaexpress/src/pages/HelpPage.jsx) | Centro de ayuda: FAQ y diagnóstico de conectividad. | `checkHealth()` → prueba `/api/v1/test`, `/api/v1/shipments`, `/api/v1/report`. | `api` |

### 1.5 Componentes

| Ruta | Responsabilidad | Elementos clave |
|---|---|---|
| [components/dashboard/DashboardLayout.jsx](file:///home/danko/Descargas/cloud_native_1-main%20EV3/frontend-rutaexpress/src/components/dashboard/DashboardLayout.jsx) | Layout común (Sidebar + Topbar) y cierre de sesión. | `handleLogout()` (`logoutRedirect`), guard de `InteractionStatus`. |
| [components/dashboard/Sidebar.jsx](file:///home/danko/Descargas/cloud_native_1-main%20EV3/frontend-rutaexpress/src/components/dashboard/Sidebar.jsx) | Navegación lateral. | `MAIN_NAV_ITEMS`, `FOOTER_NAV_ITEMS`, `NavLink`. |
| [components/dashboard/Topbar.jsx](file:///home/danko/Descargas/cloud_native_1-main%20EV3/frontend-rutaexpress/src/components/dashboard/Topbar.jsx) | Cabecera, menú de usuario, modales de perfil y confirmación de logout. | `Topbar()`, modales `showConfirm`/`showProfile`. |
| [components/dashboard/KpiCards.jsx](file:///home/danko/Descargas/cloud_native_1-main%20EV3/frontend-rutaexpress/src/components/dashboard/KpiCards.jsx) | Tarjetas KPI del dashboard. | Recibe `totalShipments`. |
| [components/dashboard/FlowCard.jsx](file:///home/danko/Descargas/cloud_native_1-main%20EV3/frontend-rutaexpress/src/components/dashboard/FlowCard.jsx) | Diagrama de etapas del flujo de trazabilidad. | `STAGES` (Creado→Entregado). |
| [components/dashboard/ShipmentTable.jsx](file:///home/danko/Descargas/cloud_native_1-main%20EV3/frontend-rutaexpress/src/components/dashboard/ShipmentTable.jsx) | Tabla resumen de envíos recientes. | `ShipmentTable({shipments})`, datos de fallback. |
| [components/shipments/CreateShipmentModal.jsx](file:///home/danko/Descargas/cloud_native_1-main%20EV3/frontend-rutaexpress/src/components/shipments/CreateShipmentModal.jsx) | Formulario modal de creación de envío. | `onSubmit(formData)` con `origin/destination/recipientName/description`. |
| [components/shipments/ShipmentTable.jsx](file:///home/danko/Descargas/cloud_native_1-main%20EV3/frontend-rutaexpress/src/components/shipments/ShipmentTable.jsx) | Tabla de envíos con selector de estado y botón "Ver Timeline". | `ESTADOS_VALIDOS`, `getStatusStyle()`, `onStatusChange`, `onViewTimeline`. |
| [components/shipments/TimelineModal.jsx](file:///home/danko/Descargas/cloud_native_1-main%20EV3/frontend-rutaexpress/src/components/shipments/TimelineModal.jsx) | Línea de tiempo de auditoría de un envío. | `getShipmentHistory()`, fallback de eventos, `getStatusIcon()`. |
| [components/shipments/ShipmentStatusBadge.jsx](file:///home/danko/Descargas/cloud_native_1-main%20EV3/frontend-rutaexpress/src/components/shipments/ShipmentStatusBadge.jsx) | Badge de estado (componente de apoyo). | Mapeo `IN_TRANSIT`/`DELIVERED` → etiqueta. |
| [components/login/*.jsx](file:///home/danko/Descargas/cloud_native_1-main%20EV3/frontend-rutaexpress/src/components/login) | Piezas del login: portada, marca, botón Microsoft, footer. | `LoginHero`, `LoginBranding`, `MicrosoftButton`, `LoginFooter`. |

---

## 2. `ms-rutaexpress-bff` (API Gateway / BFF) · puerto 8080

**Responsabilidad:** único punto de entrada HTTP. Valida JWT de Azure AD y enruta `/api/v1/**` a cada microservicio. **No tiene base de datos.**

| Ruta | Rol | Detalle |
|---|---|---|
| [controller/TestController.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-bff/src/main/java/cl/duoc/rutaexpress/bff/controller/TestController.java) | `GET /api/v1/test` | Devuelve estado y, si hay JWT, los claims del usuario (`subject`, `preferred_username`, `name`, `roles`, `scp`, `issuer`). |
| [controller/ShipmentBffController.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-bff/src/main/java/cl/duoc/rutaexpress/bff/controller/ShipmentBffController.java) | `GET /api/bff/shipments` | **Endpoint legacy**. Devuelve un mensaje indicando que debe usarse `/api/v1/shipments`. |
| [controller/ShipmentController.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-bff/src/main/java/cl/duoc/rutaexpress/bff/controller/ShipmentController.java) | — | **Clase vacía** (placeholder): el enrutamiento lo hace el Gateway. |
| [dto/ShipmentDto.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-bff/src/main/java/cl/duoc/rutaexpress/bff/dto/ShipmentDto.java) | Modelo de transporte | POJO con getters/setters (no usado activamente por el Gateway). |
| [security/SecurityConfig.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-bff/src/main/java/cl/duoc/rutaexpress/bff/security/SecurityConfig.java) | Seguridad + CORS | `SecurityFilterChain`, `JwtAuthenticationConverter` (claim `scp` → `ROLE_*`), `CorsConfigurationSource` (orígenes permitidos). |
| [security/JwtDecoderConfig.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-bff/src/main/java/cl/duoc/rutaexpress/bff/security/JwtDecoderConfig.java) | Decodificador JWT | `NimbusJwtDecoder` contra el `jwk-set-uri`, `JwtTimestampValidator` con 60 min de tolerancia. |
| [application.properties](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-bff/src/main/resources/application.properties) | Config | Rutas `spring.cloud.gateway.routes[]` y `…mvc.routes[]`, JWKS y `audiences`. |

**Dependencias internas:** no depende de otros microservicios en código; los referencia por URL (`MS_*_URL`). Depende de Azure AD (JWKS) para validar tokens.

---

## 3. `ms-rutaexpress-shipments` (Envíos) · puerto 8085

**Responsabilidad:** gestionar envíos, persistirlos en PostgreSQL y **publicar un evento** al cambiar de estado.

| Ruta | Rol | Detalle |
|---|---|---|
| [controller/ShipmentController.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-shipments/src/main/java/cl/duoc/rutaexpress/shipments/controller/ShipmentController.java) | HTTP | `GET /api/v1/shipments` (usa repo directo), `POST /api/v1/shipments`, `PATCH /api/v1/shipments/{id}/status` (usa service). |
| [service/ShipmentService.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-shipments/src/main/java/cl/duoc/rutaexpress/shipments/service/ShipmentService.java) | Negocio | `updateStatus(id, dto)`: guarda el nuevo estado y publica `ShipmentStatusEvent` a RabbitMQ (`shipment.exchange`, key `shipment.status.changed`). |
| [model/Shipment.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-shipments/src/main/java/cl/duoc/rutaexpress/shipments/model/Shipment.java) | Entidad JPA (`shipments`) | Campos: `id`, `trackingCode`, `recipientName`, `destination`, `origin`, `status`, `createdAt`. `@PrePersist` autogenera tracking y estado "Creado". |
| [dto/UpdateShipmentStatusDTO.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-shipments/src/main/java/cl/duoc/rutaexpress/shipments/dto/UpdateShipmentStatusDTO.java) | DTO | `record(status, location, user)`. |
| [event/ShipmentStatusEvent.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-shipments/src/main/java/cl/duoc/rutaexpress/shipments/event/ShipmentStatusEvent.java) | Evento | `record(shipmentId, previousStatus, newStatus, location, user, timestamp)`. |
| [repository/ShipmentRepository.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-shipments/src/main/java/cl/duoc/rutaexpress/shipments/repository/ShipmentRepository.java) | Persistencia | `JpaRepository<Shipment, Long>`. |
| [config/RabbitMQConfig.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-shipments/src/main/java/cl/duoc/rutaexpress/shipments/config/RabbitMQConfig.java) | Messaging | Declara `shipment.exchange` (Topic), `audit.shipment.queue` y binding con key `shipment.status.changed`; `Jackson2JsonMessageConverter`. |

**Dependencias internas:** PostgreSQL (JPA), RabbitMQ (producer).

---

## 4. `ms-rutaexpress-catalog` (Catálogo / Flota) · puerto 8081

**Responsabilidad:** CRUD del catálogo (vehículos, rutas, sucursales) con borrado lógico.

| Ruta | Rol | Detalle |
|---|---|---|
| [controller/CatalogController.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-catalog/src/main/java/cl/duoc/rutaexpress/catalog/controller/CatalogController.java) | HTTP | `GET /`, `GET /{id}`, `GET /category/{category}`, `POST /`, `PUT /{id}`, `DELETE /{id}` (marca `active=false`). |
| [model/CatalogItem.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-catalog/src/main/java/cl/duoc/rutaexpress/catalog/model/CatalogItem.java) | Entidad JPA (`catalog_items`) | `id`, `name`, `description`, `category`, `active`. |
| [repository/CatalogRepository.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-catalog/src/main/java/cl/duoc/rutaexpress/catalog/repository/CatalogRepository.java) | Persistencia | `findByCategory()`, `findByActiveTrue()`. |

**Dependencias internas:** PostgreSQL (JPA). Sin mensajería. El controlador usa el repositorio directamente (no hay capa `service`).

---

## 5. `ms-rutaexpress-audit` (Auditoría) · puerto 8084

**Responsabilidad:** **consumir** eventos de cambio de estado y persistirlos como log de auditoría inmutable.

| Ruta | Rol | Detalle |
|---|---|---|
| [consumer/AuditKafkaConsumer.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-audit/src/main/java/cl/duoc/rutaexpress/audit/consumer/AuditKafkaConsumer.java) | Consumidor | `@RabbitListener(queues="${app.rabbitmq.queue}")` → mapea `ShipmentStatusEvent` a `AuditLog` y lo persiste. ⚠️ La clase se llama `AuditRabbitConsumer` (ver deuda técnica). |
| [controller/AuditController.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-audit/src/main/java/cl/duoc/rutaexpress/audit/controller/AuditController.java) | HTTP | `GET /api/v1/audit/shipments[/all]` (todos) y `GET /api/v1/audit/shipments/{shipmentId:\d+}` (historial descendente). |
| [model/AuditLog.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-audit/src/main/java/cl/duoc/rutaexpress/audit/model/AuditLog.java) | Entidad JPA (`shipment_audit`) | `id`, `shipmentId`, `previousStatus`, `newStatus`, `location`, `user`, `timestamp`. |
| [event/ShipmentStatusEvent.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-audit/src/main/java/cl/duoc/rutaexpress/audit/event/ShipmentStatusEvent.java) | Evento | Mismo contrato que en `ms-shipments` (duplicado local). |
| [repository/AuditRepository.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-audit/src/main/java/cl/duoc/rutaexpress/audit/repository/AuditRepository.java) | Persistencia | `findByShipmentIdOrderByTimestampDesc()`. |
| [config/RabbitMQConfig.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-audit/src/main/java/cl/duoc/rutaexpress/audit/config/RabbitMQConfig.java) | Messaging | Declara `shipment.audit.queue` + binding a `shipment.exchange` con key `shipment.status.#`; converter con `JavaTimeModule`. |

**Dependencias internas:** RabbitMQ (consumer), PostgreSQL (JPA).

---

## 6. `ms-rutaexpress-notify` (Notificaciones) · puerto 8082

**Responsabilidad:** encolar notificaciones (producer → consumer) y administrar colas vía RabbitAdmin.

| Ruta | Rol | Detalle |
|---|---|---|
| [controller/NotifyController.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-notify/src/main/java/cl/duoc/rutaexpress/notify/controller/NotifyController.java) | HTTP | `GET /api/v1/notify`; `POST /send`; `POST /queues` (crear); `DELETE /queues/{name}` (eliminar). |
| [producer/NotificationProducer.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-notify/src/main/java/cl/duoc/rutaexpress/notify/producer/NotificationProducer.java) | Producer | `sendNotification()` publica a `notification-exchange` con key `notify.key`. |
| [consumer/NotificationConsumer.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-notify/src/main/java/cl/duoc/rutaexpress/notify/consumer/NotificationConsumer.java) | Consumer | `@RabbitListener` con **ACK/NACK manual**: loguea el "envío" y confirma con `basicAck` (o `basicNack` en error). |
| [service/RabbitAdminService.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-notify/src/main/java/cl/duoc/rutaexpress/notify/service/RabbitAdminService.java) | Administración | `createQueue()`, `deleteQueue()` usando `RabbitAdmin`. |
| [config/RabbitMQConfig.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-notify/src/main/java/cl/duoc/rutaexpress/notify/config/RabbitMQConfig.java) | Messaging | `notification-queue`, `notification-exchange` (Topic), binding `notify.key`, `RabbitAdmin`, converter JSON. |
| [dto/QueueRequestDTO.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-notify/src/main/java/cl/duoc/rutaexpress/notify/dto/QueueRequestDTO.java) | DTO validado | `name` (`@NotBlank` + `@Pattern`), `durable` (default `true`). |
| [model/NotificationMessage.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-notify/src/main/java/cl/duoc/rutaexpress/notify/model/NotificationMessage.java) | Modelo | `recipient`, `subject`, `body` (`Serializable`). |

**Dependencias internas:** RabbitMQ (producer + consumer + admin). Sin base de datos.

---

## 7. `ms-rutaexpress-report` (Reportes) · puerto 8083

**Responsabilidad:** generar un `reportId` y **publicar un evento** de reporte a RabbitMQ.

| Ruta | Rol | Detalle |
|---|---|---|
| [controller/ReportController.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-report/src/main/java/cl/duoc/rutaexpress/report/controller/ReportController.java) | HTTP | `GET /api/v1/report`; `POST /api/v1/report/generate?type=PDF` → `{message, reportId, type}`. |
| [service/ReportGeneratorService.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-report/src/main/java/cl/duoc/rutaexpress/report/service/ReportGeneratorService.java) | Negocio | `generateReport(type)`: crea `UUID`, arma `Map` y publica a `report.exchange` (key `report.generated`). |
| [config/RabbitMQConfig.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-report/src/main/java/cl/duoc/rutaexpress/report/config/RabbitMQConfig.java) | Messaging | `report.queue`, `report.exchange` (Topic), binding `report.generated`, `RabbitAdmin`. |

**Dependencias internas:** RabbitMQ (producer). Declara dependencias JPA/PostgreSQL aunque **no** tiene entidades ni repositorios.

---

## 8. Infraestructura y despliegue

| Ruta | Responsabilidad | Elementos clave |
|---|---|---|
| [docker-compose.yml](file:///home/danko/Descargas/cloud_native_1-main%20EV3/docker-compose.yml) | Orquesta 10 contenedores: Postgres, RabbitMQ, 5 microservicios, BFF y frontend. | `SPRING_PROFILES_ACTIVE=docker`, variables `SPRING_DATASOURCE_*`, `SPRING_RABBITMQ_*`, `MS_*_URL`. |
| [deploy.sh](file:///home/danko/Descargas/cloud_native_1-main%20EV3/deploy.sh) | Instala Docker/Compose y levanta el stack en EC2. | `docker-compose down && docker-compose up -d --build`. |
| [frontend-rutaexpress/nginx.conf](file:///home/danko/Descargas/cloud_native_1-main%20EV3/frontend-rutaexpress/nginx.conf) | Sirve la SPA y hace fallback a `index.html` (rutas de React Router). | `try_files $uri $uri/ /index.html`. |
| `frontend-rutaexpress/Dockerfile` | Build multi-stage `node → nginx`. | `npm install && npm run build`. |
| `ms-rutaexpress-*/Dockerfile` | Build multi-stage `maven → JRE 21`. | `mvn clean package -DskipTests`. |

---

## ⚠️ Notas Técnicas / Deuda Técnica

- **Capa de servicio inconsistente en `ms-shipments`:** [ShipmentController](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-shipments/src/main/java/cl/duoc/rutaexpress/shipments/controller/ShipmentController.java) inyecta **tanto** `ShipmentService` como `ShipmentRepository`; `GET` y `POST` saltan la capa de servicio. Lo ideal es todo vía `service`.
- **Evento duplicado entre servicios:** [ShipmentStatusEvent](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-shipments/src/main/java/cl/duoc/rutaexpress/shipments/event/ShipmentStatusEvent.java) está definido **por separado** en `ms-shipments` y `ms-audit`. Al no existir un módulo de contrato compartido, cualquier cambio debe replicarse manualmente.
- **`ms-report` sin persistencia real:** declara JPA y PostgreSQL pero no tiene entidades/repositorios; la "generación" solo publica un evento con un `UUID` (no produce archivos PDF/CSV/Excel reales).
- **`ms-notify` no envía notificaciones reales:** el consumer solo hace `log.info` simulando el envío; no hay integración con SMTP/SMS.
- **Datos de demostración hardcodeados en el frontend:** varias páginas contienen arrays de fallback (envíos, camiones, reportes, auditoría). En un entorno productivo deben eliminarse.
- **Componente huérfano:** [ShipmentStatusBadge.jsx](file:///home/danko/Descargas/cloud_native_1-main%20EV3/frontend-rutaexpress/src/components/shipments/ShipmentStatusBadge.jsx) no se importa en ninguna página/componente.
- **`ShipmentController.java` del BFF** es una clase vacía sin anotaciones (código muerto).
