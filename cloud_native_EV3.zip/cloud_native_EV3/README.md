# 🚚 RutaExpress — Plataforma Cloud Native de Gestión Logística

## Resumen

**RutaExpress** es una plataforma web para la **gestión logística de encomiendas**: alta y seguimiento de envíos, administración de flota de camiones, generación de reportes, notificaciones asíncronas y trazabilidad/auditoría inmutable del ciclo de vida de cada envío.

El sistema está construido con una **arquitectura de microservicios** detrás de un **BFF (Backend For Frontend) que actúa como API Gateway**, autenticación corporativa con **Microsoft Entra ID (Azure AD)**, persistencia relacional en **PostgreSQL** y mensajería asíncrona basada en eventos con **RabbitMQ**.

Resuelve el problema de **centralizar y desacoplar** los distintos dominios logísticos (envíos, catálogo, reportes, notificaciones, auditoría) permitiendo que cada dominio evolucione, escale y se despliegue de forma independiente, con un único punto de entrada seguro para el frontend.

---

## Stack Tecnológico

| Capa | Tecnología |
|---|---|
| **Backend (lenguaje)** | Java 21 |
| **Backend (framework)** | Spring Boot 3.2.5 |
| **API Gateway / BFF** | Spring Cloud Gateway (WebMVC) + Spring Web |
| **Seguridad** | Spring Security OAuth2 Resource Server (JWT) + Microsoft Entra ID |
| **Persistencia** | Spring Data JPA / Hibernate + PostgreSQL 16 |
| **Mensajería** | Spring AMQP + RabbitMQ 3 (Topic Exchanges) |
| **Frontend** | React 19 + Vite 8 + React Router 7 |
| **Estilos** | TailwindCSS 4 + estilos inline |
| **Cliente HTTP** | Axios (con interceptores JWT) |
| **Autenticación frontend** | MSAL (`@azure/msal-browser`, `@azure/msal-react`) |
| **Iconografía** | lucide-react |
| **Linter** | oxlint |
| **Contenedores** | Docker (multi-stage) + Docker Compose + Nginx |
| **Cloud** | AWS EC2 (despliegue) |

---

## Inicio Rápido (Quick Start)

### Requisitos previos
- **Docker** y **Docker Compose** instalados.
- (Opcional, solo para desarrollo local sin Docker) **JDK 21**, **Maven 3.9+**, **Node.js 20+**.

### 1. Clonar el repositorio

```bash
git clone <URL_DEL_REPOSITORIO>
cd "cloud_native_1-main EV3"
```

### 2. Configurar variables de entorno

El frontend ya incluye un archivo [frontend-rutaexpress/.env](file:///home/danko/Descargas/cloud_native_1-main%20EV3/frontend-rutaexpress/.env) de ejemplo. Para un entorno local basta con:

```env
VITE_API_URL=http://localhost:8080
VITE_AZURE_CLIENT_ID=<tu_client_id>
VITE_AZURE_TENANT_ID=<tu_tenant_id>
VITE_AZURE_REDIRECT_URI=http://localhost:5173
```

> El resto de los microservicios no requiere `.env`: reciben su configuración por variables de entorno inyectadas desde [docker-compose.yml](file:///home/danko/Descargas/cloud_native_1-main%20EV3/docker-compose.yml) y usan valores por defecto. Ver detalle en [04-herramientas-y-configuracion.md](docs/04-herramientas-y-configuracion.md).

### 3. Levantar todo el sistema

```bash
docker compose up -d --build
```

O usando el script de despliegue incluido:

```bash
chmod +x deploy.sh && ./deploy.sh
```

### 4. Acceder a los servicios

| Servicio | URL |
|---|---|
| Frontend (React/Nginx) | http://localhost:5173 |
| API Gateway / BFF | http://localhost:8080/api/v1/test |
| RabbitMQ Console | http://localhost:15672 (user / password) |
| PostgreSQL | `localhost:5432` (db `rutaexpress`) |

Para desarrollo del frontend en caliente (sin reconstruir contenedores):

```bash
cd frontend-rutaexpress
npm install
npm run dev        # http://localhost:5173
```

---

## Mapa de Documentación (Índice)

| Documento | Contenido |
|---|---|
| [docs/01-arquitectura-y-estructura.md](docs/01-arquitectura-y-estructura.md) | Árbol de directorios, diagrama de arquitectura (Mermaid) y patrones de diseño usados. |
| [docs/02-componentes-y-modulos.md](docs/02-componentes-y-modulos.md) | Desglose módulo a módulo: rutas, responsabilidades, clases/funciones clave y dependencias internas. |
| [docs/03-api-y-flujos-de-datos.md](docs/03-api-y-flujos-de-datos.md) | Tabla de endpoints/rutas y diagramas de secuencia de los flujos críticos (autenticación, eventos, reportes). |
| [docs/04-herramientas-y-configuracion.md](docs/04-herramientas-y-configuracion.md) | Dependencias externas, variables de entorno, scripts/comandos y notas de deuda técnica. |
| [docs/AWS_EC2_DEPLOYMENT.md](docs/AWS_EC2_DEPLOYMENT.md) | Guía paso a paso de despliegue en Amazon EC2. |

---

## Arquitectura en una imagen

```mermaid
graph LR
    U[Usuario] -->|HTTPS| FE[Frontend React + Nginx :5173]
    FE -->|JWT Bearer| BFF[ms-bff API Gateway :8080]
    BFF --> S[ms-shipments :8085]
    BFF --> C[ms-catalog :8081]
    BFF --> R[ms-report :8083]
    BFF --> A[ms-audit :8084]
    BFF --> N[ms-notify :8082]
    S -->|evento| MQ[(RabbitMQ)]
    R -->|evento| MQ
    MQ -->|evento| A
    MQ -->|mensaje| N
    S --> DB[(PostgreSQL)]
    C --> DB
    R --> DB
    A --> DB
```

> Detalle completo, con el flujo de datos y capas, en [01-arquitectura-y-estructura.md](docs/01-arquitectura-y-estructura.md).

---

## ⚠️ Notas Técnicas / Deuda Técnica

- **Inconsistencia de mensajería (Kafka/MongoDB vs RabbitMQ/PostgreSQL):** gran parte de los textos del frontend (FAQ, tarjetas del dashboard, páginas de Auditoría/Reportes/Ajustes) y el documento [AWS_EC2_DEPLOYMENT.md](file:///home/danko/Descargas/cloud_native_1-main%20EV3/docs/AWS_EC2_DEPLOYMENT.md) describen **Kafka** y **MongoDB**. El código real y [docker-compose.yml](file:///home/danko/Descargas/cloud_native_1-main%20EV3/docker-compose.yml) **no contienen Kafka ni MongoDB**: la mensajería es **RabbitMQ** y la auditoría persiste en **PostgreSQL**. Ver "Deuda Técnica" en cada documento.
- **Archivo con nombre de clase incorrecto:** [AuditKafkaConsumer.java](file:///home/danko/Descargas/cloud_native_1-main%20EV3/ms-rutaexpress-audit/src/main/java/cl/duoc/rutaexpress/audit/consumer/AuditKafkaConsumer.java) declara `public class AuditRabbitConsumer`, lo que **rompe la compilación de Java** (el nombre del archivo debe coincidir con la clase pública).
- **Puerta de entrada:** el acceso directo al sistema requiere credenciales de Azure AD válidas configuradas en el `.env`; sin ellas no es posible autenticarse.
