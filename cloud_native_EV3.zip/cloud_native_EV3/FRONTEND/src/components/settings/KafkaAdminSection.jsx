import React, { useState, useEffect } from 'react';
import {
    getKafkaTopics,
    getKafkaTopicDetails,
    createKafkaTopic,
    updateKafkaTopic,
    deleteKafkaTopic,
    getKafkaConsumerGroups,
    getKafkaConsumerGroupDetails,
    deleteKafkaConsumerGroup
} from '../../services/kafkaAdminService';
import {
    Layers,
    Plus,
    RefreshCw,
    Trash2,
    Sliders,
    Eye,
    X,
    ExternalLink,
    AlertCircle,
    CheckCircle2,
    Users,
    Server
} from 'lucide-react';

export default function KafkaAdminSection() {
    const [activeTab, setActiveTab] = useState('topics'); // 'topics' | 'groups'
    const [topics, setTopics] = useState([]);
    const [consumerGroups, setConsumerGroups] = useState([]);
    const [loading, setLoading] = useState(false);
    const [feedback, setFeedback] = useState(null); // { type: 'success' | 'error', message: '' }

    // Modales y drawers
    const [showCreateModal, setShowCreateModal] = useState(false);
    const [inspectTopic, setInspectTopic] = useState(null);
    const [editTopic, setEditTopic] = useState(null);
    const [inspectGroup, setInspectGroup] = useState(null);

    // Formulario de creación
    const [newTopic, setNewTopic] = useState({
        name: '',
        partitions: 3,
        replicationFactor: 1,
        retentionMs: 604800000, // 7 días por defecto
        cleanupPolicy: 'delete'
    });

    // Formulario de edición
    const [updateForm, setUpdateForm] = useState({
        partitions: '',
        retentionMs: '',
        cleanupPolicy: ''
    });

    const showNotification = (type, message) => {
        setFeedback({ type, message });
        setTimeout(() => setFeedback(null), 4000);
    };

    const loadAll = async () => {
        setLoading(true);
        try {
            const [topicsData, groupsData] = await Promise.all([
                getKafkaTopics().catch(err => {
                    console.warn("Error cargando tópicos:", err);
                    return [];
                }),
                getKafkaConsumerGroups().catch(err => {
                    console.warn("Error cargando consumer groups:", err);
                    return [];
                })
            ]);
            setTopics(topicsData || []);
            setConsumerGroups(groupsData || []);
        } catch (error) {
            showNotification('error', 'Error al consultar el servicio de administración Kafka');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadAll();
    }, []);

    // Crear tópico
    const handleCreate = async (e) => {
        e.preventDefault();
        if (!newTopic.name.trim()) {
            showNotification('error', 'El nombre del tópico es obligatorio.');
            return;
        }

        try {
            await createKafkaTopic({
                name: newTopic.name.trim(),
                partitions: Number(newTopic.partitions) || 1,
                replicationFactor: Number(newTopic.replicationFactor) || 1,
                retentionMs: newTopic.retentionMs ? Number(newTopic.retentionMs) : null,
                cleanupPolicy: newTopic.cleanupPolicy || 'delete'
            });
            showNotification('success', `Tópico '${newTopic.name}' creado exitosamente.`);
            setShowCreateModal(false);
            setNewTopic({ name: '', partitions: 3, replicationFactor: 1, retentionMs: 604800000, cleanupPolicy: 'delete' });
            loadAll();
        } catch (error) {
            const errMsg = error.response?.data?.error || error.message || 'Error al crear tópico.';
            showNotification('error', errMsg);
        }
    };

    // Inspeccionar tópico
    const handleInspectTopic = async (name) => {
        try {
            const details = await getKafkaTopicDetails(name);
            setInspectTopic(details);
        } catch (error) {
            showNotification('error', `No se pudo inspeccionar el tópico: ${error.message}`);
        }
    };

    // Abrir edición de tópico
    const openEditTopic = (t) => {
        setEditTopic(t);
        setUpdateForm({
            partitions: '',
            retentionMs: '',
            cleanupPolicy: ''
        });
    };

    // Guardar edición de tópico
    const handleUpdate = async (e) => {
        e.preventDefault();
        if (!editTopic) return;

        const payload = {};
        if (updateForm.partitions) payload.partitions = Number(updateForm.partitions);
        if (updateForm.retentionMs) payload.retentionMs = Number(updateForm.retentionMs);
        if (updateForm.cleanupPolicy) payload.cleanupPolicy = updateForm.cleanupPolicy;

        if (Object.keys(payload).length === 0) {
            showNotification('error', 'Ingresa al menos un cambio de configuración o particiones.');
            return;
        }

        try {
            await updateKafkaTopic(editTopic.name, payload);
            showNotification('success', `Tópico '${editTopic.name}' actualizado.`);
            setEditTopic(null);
            loadAll();
        } catch (error) {
            const errMsg = error.response?.data?.error || error.message || 'Error al actualizar tópico.';
            showNotification('error', errMsg);
        }
    };

    // Eliminar tópico
    const handleDeleteTopic = async (name) => {
        if (!window.confirm(`¿Estás seguro de eliminar el tópico '${name}' permanentemente?`)) return;

        try {
            await deleteKafkaTopic(name);
            showNotification('success', `Tópico '${name}' eliminado.`);
            loadAll();
        } catch (error) {
            showNotification('error', `Error al eliminar tópico: ${error.message}`);
        }
    };

    // Inspeccionar consumer group
    const handleInspectGroup = async (groupId) => {
        try {
            const details = await getKafkaConsumerGroupDetails(groupId);
            setInspectGroup(details);
        } catch (error) {
            showNotification('error', `No se pudo inspeccionar el grupo: ${error.message}`);
        }
    };

    // Eliminar consumer group
    const handleDeleteGroup = async (groupId) => {
        if (!window.confirm(`¿Estás seguro de eliminar el Consumer Group '${groupId}'?`)) return;

        try {
            await deleteKafkaConsumerGroup(groupId);
            showNotification('success', `Consumer Group '${groupId}' eliminado.`);
            loadAll();
        } catch (error) {
            showNotification('error', `Error al eliminar grupo: ${error.message}`);
        }
    };

    return (
        <div style={{ backgroundColor: '#fff', borderRadius: '12px', border: '1px solid #e2e8f0', boxShadow: '0 1px 3px rgba(0,0,0,0.05)', overflow: 'hidden' }}>
            {/* Header de la sección */}
            <div style={{ padding: '16px 20px', borderBottom: '1px solid #f1f5f9', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '12px' }}>
                <div>
                    <div style={{ fontWeight: '700', fontSize: '16px', color: '#0f172a', display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <span style={{ fontSize: '20px' }}>⚡</span> Panel de Administración Apache Kafka
                        <span style={{ fontSize: '11px', backgroundColor: '#e0f2fe', color: '#0369a1', padding: '2px 8px', borderRadius: '12px', fontWeight: '600' }}>
                            Broker 9092
                        </span>
                    </div>
                    <div style={{ fontSize: '12px', color: '#64748b', marginTop: '2px' }}>
                        Gestión en tiempo real de tópicos, particiones, retención y consumer groups vía ms-notify
                    </div>
                </div>

                <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                    <a
                        href="http://localhost:8090"
                        target="_blank"
                        rel="noreferrer"
                        style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '12px', fontWeight: '600', color: '#475569', backgroundColor: '#f8fafc', padding: '6px 12px', borderRadius: '8px', border: '1px solid #e2e8f0', textDecoration: 'none' }}
                        title="Abrir Kafka UI en el puerto 8090"
                    >
                        <ExternalLink size={14} /> Kafka UI (8090)
                    </a>
                    <button
                        onClick={loadAll}
                        disabled={loading}
                        style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '12px', fontWeight: '600', color: '#334155', backgroundColor: '#f1f5f9', padding: '6px 12px', borderRadius: '8px', border: 'none', cursor: 'pointer' }}
                    >
                        <RefreshCw size={14} className={loading ? 'animate-spin' : ''} /> Actualizar
                    </button>
                    <button
                        onClick={() => setShowCreateModal(true)}
                        style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '12px', fontWeight: '600', color: '#fff', backgroundColor: '#2563eb', padding: '6px 14px', borderRadius: '8px', border: 'none', cursor: 'pointer' }}
                    >
                        <Plus size={14} /> Nuevo Tópico
                    </button>
                </div>
            </div>

            {/* Notificación Feedback */}
            {feedback && (
                <div style={{
                    margin: '12px 20px 0 20px',
                    padding: '10px 14px',
                    borderRadius: '8px',
                    fontSize: '13px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    backgroundColor: feedback.type === 'success' ? '#f0fdf4' : '#fef2f2',
                    color: feedback.type === 'success' ? '#16a34a' : '#dc2626',
                    border: `1px solid ${feedback.type === 'success' ? '#bbf7d0' : '#fecaca'}`
                }}>
                    {feedback.type === 'success' ? <CheckCircle2 size={16} /> : <AlertCircle size={16} />}
                    {feedback.message}
                </div>
            )}

            {/* Pestañas de Navegación */}
            <div style={{ display: 'flex', borderBottom: '1px solid #f1f5f9', padding: '0 20px', marginTop: '12px', gap: '20px' }}>
                <button
                    onClick={() => setActiveTab('topics')}
                    style={{
                        padding: '10px 4px',
                        fontSize: '13px',
                        fontWeight: '600',
                        color: activeTab === 'topics' ? '#2563eb' : '#64748b',
                        borderBottom: activeTab === 'topics' ? '2px solid #2563eb' : '2px solid transparent',
                        backgroundColor: 'transparent',
                        borderTop: 'none', borderLeft: 'none', borderRight: 'none',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px'
                    }}
                >
                    <Layers size={16} /> Tópicos ({topics.length})
                </button>
                <button
                    onClick={() => setActiveTab('groups')}
                    style={{
                        padding: '10px 4px',
                        fontSize: '13px',
                        fontWeight: '600',
                        color: activeTab === 'groups' ? '#2563eb' : '#64748b',
                        borderBottom: activeTab === 'groups' ? '2px solid #2563eb' : '2px solid transparent',
                        backgroundColor: 'transparent',
                        borderTop: 'none', borderLeft: 'none', borderRight: 'none',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px'
                    }}
                >
                    <Users size={16} /> Consumer Groups ({consumerGroups.length})
                </button>
            </div>

            {/* Contenido de la pestaña */}
            <div style={{ padding: '20px' }}>
                {activeTab === 'topics' ? (
                    <div>
                        {topics.length === 0 ? (
                            <div style={{ textAlign: 'center', padding: '30px', color: '#94a3b8', fontSize: '13px' }}>
                                No se encontraron tópicos disponibles en el cluster de Kafka.
                            </div>
                        ) : (
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                                {topics.map(t => (
                                    <div
                                        key={t.name}
                                        style={{
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'space-between',
                                            padding: '12px 16px',
                                            borderRadius: '8px',
                                            border: '1px solid #f1f5f9',
                                            backgroundColor: '#fcfcfc'
                                        }}
                                    >
                                        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                                            <span style={{ fontSize: '18px' }}>📁</span>
                                            <div>
                                                <div style={{ fontWeight: '600', fontSize: '13px', color: '#1e293b' }}>
                                                    {t.name}
                                                </div>
                                                <div style={{ fontSize: '11px', color: '#94a3b8', display: 'flex', gap: '8px', marginTop: '2px' }}>
                                                    {t.internal ? (
                                                        <span style={{ color: '#d97706', fontWeight: '500' }}>Tópico Interno</span>
                                                    ) : (
                                                        <span style={{ color: '#16a34a', fontWeight: '500' }}>Tópico Público</span>
                                                    )}
                                                </div>
                                            </div>
                                        </div>

                                        <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                                            <button
                                                onClick={() => handleInspectTopic(t.name)}
                                                style={{ padding: '6px 10px', fontSize: '12px', fontWeight: '500', color: '#334155', backgroundColor: '#f1f5f9', border: 'none', borderRadius: '6px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '4px' }}
                                                title="Inspeccionar detalles y configuraciones"
                                            >
                                                <Eye size={13} /> Ver Detalle
                                            </button>
                                            <button
                                                onClick={() => openEditTopic(t)}
                                                style={{ padding: '6px 10px', fontSize: '12px', fontWeight: '500', color: '#2563eb', backgroundColor: '#eff6ff', border: 'none', borderRadius: '6px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '4px' }}
                                                title="Editar particiones o retención"
                                            >
                                                <Sliders size={13} /> Configurar
                                            </button>
                                            <button
                                                onClick={() => handleDeleteTopic(t.name)}
                                                style={{ padding: '6px 8px', fontSize: '12px', color: '#ef4444', backgroundColor: '#fef2f2', border: 'none', borderRadius: '6px', cursor: 'pointer', display: 'flex', alignItems: 'center' }}
                                                title="Eliminar tópico"
                                            >
                                                <Trash2 size={13} />
                                            </button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                ) : (
                    <div>
                        {consumerGroups.length === 0 ? (
                            <div style={{ textAlign: 'center', padding: '30px', color: '#94a3b8', fontSize: '13px' }}>
                                No hay consumer groups activos o registrados actualmente en el cluster.
                            </div>
                        ) : (
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                                {consumerGroups.map(g => (
                                    <div
                                        key={g.groupId}
                                        style={{
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'space-between',
                                            padding: '12px 16px',
                                            borderRadius: '8px',
                                            border: '1px solid #f1f5f9',
                                            backgroundColor: '#fcfcfc'
                                        }}
                                    >
                                        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                                            <Server size={18} color="#64748b" />
                                            <div>
                                                <div style={{ fontWeight: '600', fontSize: '13px', color: '#1e293b' }}>
                                                    {g.groupId}
                                                </div>
                                                <div style={{ fontSize: '11px', color: '#94a3b8', display: 'flex', gap: '10px', marginTop: '2px' }}>
                                                    <span>Estado: <strong style={{ color: g.state === 'STABLE' ? '#16a34a' : '#d97706' }}>{g.state}</strong></span>
                                                    <span>{g.isSimpleConsumerGroup ? 'Simple' : 'Managed'}</span>
                                                </div>
                                            </div>
                                        </div>

                                        <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                                            <button
                                                onClick={() => handleInspectGroup(g.groupId)}
                                                style={{ padding: '6px 10px', fontSize: '12px', fontWeight: '500', color: '#334155', backgroundColor: '#f1f5f9', border: 'none', borderRadius: '6px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '4px' }}
                                            >
                                                <Eye size={13} /> Inspeccionar
                                            </button>
                                            <button
                                                onClick={() => handleDeleteGroup(g.groupId)}
                                                style={{ padding: '6px 8px', fontSize: '12px', color: '#ef4444', backgroundColor: '#fef2f2', border: 'none', borderRadius: '6px', cursor: 'pointer', display: 'flex', alignItems: 'center' }}
                                                title="Eliminar grupo"
                                            >
                                                <Trash2 size={13} />
                                            </button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                )}
            </div>

            {/* Modal: Crear Tópico */}
            {showCreateModal && (
                <div style={{
                    position: 'fixed', inset: 0, backgroundColor: 'rgba(15, 23, 42, 0.5)',
                    display: 'flex', justifyContent: 'center', alignItems: 'center', zIndex: 999
                }}>
                    <div style={{ backgroundColor: '#fff', borderRadius: '14px', width: '90%', maxWidth: '460px', padding: '24px', boxShadow: '0 20px 25px -5px rgba(0,0,0,0.1)' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
                            <div style={{ fontWeight: '700', fontSize: '16px', color: '#0f172a' }}>➕ Crear Nuevo Tópico Kafka</div>
                            <button onClick={() => setShowCreateModal(false)} style={{ border: 'none', background: 'none', cursor: 'pointer', color: '#94a3b8' }}>
                                <X size={18} />
                            </button>
                        </div>

                        <form onSubmit={handleCreate} style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
                            <div>
                                <label style={{ fontSize: '12px', fontWeight: '600', color: '#475569', display: 'block', marginBottom: '4px' }}>
                                    Nombre del Tópico *
                                </label>
                                <input
                                    type="text"
                                    required
                                    placeholder="ej: rutaexpress-shipments-events"
                                    value={newTopic.name}
                                    onChange={e => setNewTopic({ ...newTopic, name: e.target.value })}
                                    style={{ width: '100%', padding: '8px 12px', borderRadius: '8px', border: '1px solid #cbd5e1', fontSize: '13px' }}
                                />
                            </div>

                            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                                <div>
                                    <label style={{ fontSize: '12px', fontWeight: '600', color: '#475569', display: 'block', marginBottom: '4px' }}>
                                        Particiones
                                    </label>
                                    <input
                                        type="number"
                                        min="1"
                                        value={newTopic.partitions}
                                        onChange={e => setNewTopic({ ...newTopic, partitions: e.target.value })}
                                        style={{ width: '100%', padding: '8px 12px', borderRadius: '8px', border: '1px solid #cbd5e1', fontSize: '13px' }}
                                    />
                                </div>
                                <div>
                                    <label style={{ fontSize: '12px', fontWeight: '600', color: '#475569', display: 'block', marginBottom: '4px' }}>
                                        Factor Replicación
                                    </label>
                                    <input
                                        type="number"
                                        min="1"
                                        value={newTopic.replicationFactor}
                                        onChange={e => setNewTopic({ ...newTopic, replicationFactor: e.target.value })}
                                        style={{ width: '100%', padding: '8px 12px', borderRadius: '8px', border: '1px solid #cbd5e1', fontSize: '13px' }}
                                    />
                                </div>
                            </div>

                            <div>
                                <label style={{ fontSize: '12px', fontWeight: '600', color: '#475569', display: 'block', marginBottom: '4px' }}>
                                    Retention (retention.ms)
                                </label>
                                <select
                                    value={newTopic.retentionMs}
                                    onChange={e => setNewTopic({ ...newTopic, retentionMs: Number(e.target.value) })}
                                    style={{ width: '100%', padding: '8px 12px', borderRadius: '8px', border: '1px solid #cbd5e1', fontSize: '13px', backgroundColor: '#fff' }}
                                >
                                    <option value={86400000}>1 Día (86,400,000 ms)</option>
                                    <option value={604800000}>7 Días (604,800,000 ms - Estándar)</option>
                                    <option value={2592000000}>30 Días (2,592,000,000 ms)</option>
                                    <option value={-1}>Infinito (-1)</option>
                                </select>
                            </div>

                            <div>
                                <label style={{ fontSize: '12px', fontWeight: '600', color: '#475569', display: 'block', marginBottom: '4px' }}>
                                    Política de Limpieza (cleanup.policy)
                                </label>
                                <select
                                    value={newTopic.cleanupPolicy}
                                    onChange={e => setNewTopic({ ...newTopic, cleanupPolicy: e.target.value })}
                                    style={{ width: '100%', padding: '8px 12px', borderRadius: '8px', border: '1px solid #cbd5e1', fontSize: '13px', backgroundColor: '#fff' }}
                                >
                                    <option value="delete">delete (Eliminar por retención/tamaño)</option>
                                    <option value="compact">compact (Compactar por key)</option>
                                    <option value="compact,delete">compact,delete (Compactar y expirar)</option>
                                </select>
                            </div>

                            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px', marginTop: '12px' }}>
                                <button
                                    type="button"
                                    onClick={() => setShowCreateModal(false)}
                                    style={{ padding: '8px 16px', borderRadius: '8px', border: '1px solid #e2e8f0', backgroundColor: '#f8fafc', fontSize: '13px', fontWeight: '600', color: '#64748b', cursor: 'pointer' }}
                                >
                                    Cancelar
                                </button>
                                <button
                                    type="submit"
                                    style={{ padding: '8px 18px', borderRadius: '8px', border: 'none', backgroundColor: '#2563eb', fontSize: '13px', fontWeight: '600', color: '#fff', cursor: 'pointer' }}
                                >
                                    Crear Tópico
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {/* Modal: Editar Configuraciones o Particiones */}
            {editTopic && (
                <div style={{
                    position: 'fixed', inset: 0, backgroundColor: 'rgba(15, 23, 42, 0.5)',
                    display: 'flex', justifyContent: 'center', alignItems: 'center', zIndex: 999
                }}>
                    <div style={{ backgroundColor: '#fff', borderRadius: '14px', width: '90%', maxWidth: '440px', padding: '24px', boxShadow: '0 20px 25px -5px rgba(0,0,0,0.1)' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
                            <div style={{ fontWeight: '700', fontSize: '16px', color: '#0f172a' }}>
                                ⚙️ Configurar: {editTopic.name}
                            </div>
                            <button onClick={() => setEditTopic(null)} style={{ border: 'none', background: 'none', cursor: 'pointer', color: '#94a3b8' }}>
                                <X size={18} />
                            </button>
                        </div>

                        <form onSubmit={handleUpdate} style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
                            <div>
                                <label style={{ fontSize: '12px', fontWeight: '600', color: '#475569', display: 'block', marginBottom: '4px' }}>
                                    Aumentar Particiones (Kafka no permite reducir)
                                </label>
                                <input
                                    type="number"
                                    min="1"
                                    placeholder="Dejar vacío para no cambiar"
                                    value={updateForm.partitions}
                                    onChange={e => setUpdateForm({ ...updateForm, partitions: e.target.value })}
                                    style={{ width: '100%', padding: '8px 12px', borderRadius: '8px', border: '1px solid #cbd5e1', fontSize: '13px' }}
                                />
                            </div>

                            <div>
                                <label style={{ fontSize: '12px', fontWeight: '600', color: '#475569', display: 'block', marginBottom: '4px' }}>
                                    Nueva Retención (retention.ms)
                                </label>
                                <select
                                    value={updateForm.retentionMs}
                                    onChange={e => setUpdateForm({ ...updateForm, retentionMs: e.target.value })}
                                    style={{ width: '100%', padding: '8px 12px', borderRadius: '8px', border: '1px solid #cbd5e1', fontSize: '13px', backgroundColor: '#fff' }}
                                >
                                    <option value="">-- Sin cambio --</option>
                                    <option value="86400000">1 Día (86,400,000 ms)</option>
                                    <option value="604800000">7 Días (604,800,000 ms)</option>
                                    <option value="2592000000">30 Días (2,592,000,000 ms)</option>
                                    <option value="-1">Infinito (-1)</option>
                                </select>
                            </div>

                            <div>
                                <label style={{ fontSize: '12px', fontWeight: '600', color: '#475569', display: 'block', marginBottom: '4px' }}>
                                    Política de Limpieza (cleanup.policy)
                                </label>
                                <select
                                    value={updateForm.cleanupPolicy}
                                    onChange={e => setUpdateForm({ ...updateForm, cleanupPolicy: e.target.value })}
                                    style={{ width: '100%', padding: '8px 12px', borderRadius: '8px', border: '1px solid #cbd5e1', fontSize: '13px', backgroundColor: '#fff' }}
                                >
                                    <option value="">-- Sin cambio --</option>
                                    <option value="delete">delete</option>
                                    <option value="compact">compact</option>
                                    <option value="compact,delete">compact,delete</option>
                                </select>
                            </div>

                            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px', marginTop: '12px' }}>
                                <button
                                    type="button"
                                    onClick={() => setEditTopic(null)}
                                    style={{ padding: '8px 16px', borderRadius: '8px', border: '1px solid #e2e8f0', backgroundColor: '#f8fafc', fontSize: '13px', fontWeight: '600', color: '#64748b', cursor: 'pointer' }}
                                >
                                    Cancelar
                                </button>
                                <button
                                    type="submit"
                                    style={{ padding: '8px 18px', borderRadius: '8px', border: 'none', backgroundColor: '#2563eb', fontSize: '13px', fontWeight: '600', color: '#fff', cursor: 'pointer' }}
                                >
                                    Guardar Cambios
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {/* Modal: Inspeccionar Tópico */}
            {inspectTopic && (
                <div style={{
                    position: 'fixed', inset: 0, backgroundColor: 'rgba(15, 23, 42, 0.5)',
                    display: 'flex', justifyContent: 'center', alignItems: 'center', zIndex: 999
                }}>
                    <div style={{ backgroundColor: '#fff', borderRadius: '14px', width: '90%', maxWidth: '580px', maxHeight: '85vh', overflowY: 'auto', padding: '24px', boxShadow: '0 20px 25px -5px rgba(0,0,0,0.1)' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
                            <div>
                                <div style={{ fontWeight: '700', fontSize: '16px', color: '#0f172a' }}>🔍 Detalle de Tópico</div>
                                <div style={{ fontSize: '13px', color: '#2563eb', fontWeight: '600' }}>{inspectTopic.name}</div>
                            </div>
                            <button onClick={() => setInspectTopic(null)} style={{ border: 'none', background: 'none', cursor: 'pointer', color: '#94a3b8' }}>
                                <X size={18} />
                            </button>
                        </div>

                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', marginBottom: '16px', backgroundColor: '#f8fafc', padding: '12px', borderRadius: '8px', fontSize: '12px' }}>
                            <div>Total Particiones: <strong>{inspectTopic.partitionsCount}</strong></div>
                            <div>Factor Replicación: <strong>{inspectTopic.replicationFactor}</strong></div>
                        </div>

                        {/* Particiones */}
                        <div style={{ marginBottom: '16px' }}>
                            <div style={{ fontSize: '13px', fontWeight: '700', color: '#334155', marginBottom: '8px' }}>Particiones y Líderes</div>
                            <div style={{ border: '1px solid #f1f5f9', borderRadius: '8px', overflow: 'hidden' }}>
                                <table style={{ width: '100%', fontSize: '12px', textAlign: 'left', borderCollapse: 'collapse' }}>
                                    <thead style={{ backgroundColor: '#f8fafc', color: '#64748b' }}>
                                        <tr>
                                            <th style={{ padding: '8px 12px' }}>Partición</th>
                                            <th style={{ padding: '8px 12px' }}>Líder</th>
                                            <th style={{ padding: '8px 12px' }}>Réplicas</th>
                                            <th style={{ padding: '8px 12px' }}>ISR</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {inspectTopic.partitions?.map(p => (
                                            <tr key={p.partition} style={{ borderTop: '1px solid #f1f5f9' }}>
                                                <td style={{ padding: '8px 12px', fontWeight: '600' }}>#{p.partition}</td>
                                                <td style={{ padding: '8px 12px' }}>Broker {p.leader}</td>
                                                <td style={{ padding: '8px 12px' }}>[{p.replicas?.join(', ')}]</td>
                                                <td style={{ padding: '8px 12px', color: '#16a34a' }}>[{p.isr?.join(', ')}]</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        {/* Configuraciones Clave */}
                        <div>
                            <div style={{ fontSize: '13px', fontWeight: '700', color: '#334155', marginBottom: '8px' }}>Configuraciones Principales</div>
                            <div style={{ backgroundColor: '#f8fafc', padding: '10px', borderRadius: '8px', fontSize: '12px', display: 'flex', flexDirection: 'column', gap: '6px' }}>
                                <div>retention.ms: <code>{inspectTopic.configs?.['retention.ms'] || 'default'}</code></div>
                                <div>cleanup.policy: <code>{inspectTopic.configs?.['cleanup.policy'] || 'delete'}</code></div>
                                <div>max.message.bytes: <code>{inspectTopic.configs?.['max.message.bytes'] || 'default'}</code></div>
                            </div>
                        </div>

                        <div style={{ marginTop: '20px', display: 'flex', justifyContent: 'flex-end' }}>
                            <button
                                onClick={() => setInspectTopic(null)}
                                style={{ padding: '8px 16px', borderRadius: '8px', border: '1px solid #cbd5e1', backgroundColor: '#fff', fontSize: '13px', fontWeight: '600', color: '#475569', cursor: 'pointer' }}
                            >
                                Cerrar
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Modal: Inspeccionar Consumer Group */}
            {inspectGroup && (
                <div style={{
                    position: 'fixed', inset: 0, backgroundColor: 'rgba(15, 23, 42, 0.5)',
                    display: 'flex', justifyContent: 'center', alignItems: 'center', zIndex: 999
                }}>
                    <div style={{ backgroundColor: '#fff', borderRadius: '14px', width: '90%', maxWidth: '580px', maxHeight: '85vh', overflowY: 'auto', padding: '24px', boxShadow: '0 20px 25px -5px rgba(0,0,0,0.1)' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
                            <div>
                                <div style={{ fontWeight: '700', fontSize: '16px', color: '#0f172a' }}>👥 Detalle de Consumer Group</div>
                                <div style={{ fontSize: '13px', color: '#2563eb', fontWeight: '600' }}>{inspectGroup.groupId}</div>
                            </div>
                            <button onClick={() => setInspectGroup(null)} style={{ border: 'none', background: 'none', cursor: 'pointer', color: '#94a3b8' }}>
                                <X size={18} />
                            </button>
                        </div>

                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginBottom: '16px', backgroundColor: '#f8fafc', padding: '12px', borderRadius: '8px', fontSize: '12px' }}>
                            <div>Estado: <strong style={{ color: inspectGroup.state === 'STABLE' ? '#16a34a' : '#d97706' }}>{inspectGroup.state}</strong></div>
                            <div>Coordinador: <strong>Broker {inspectGroup.coordinatorId ?? 'N/A'}</strong></div>
                            <div>Asignador: <strong>{inspectGroup.partitionAssignor || 'N/A'}</strong></div>
                            <div>Miembros Activos: <strong>{inspectGroup.members?.length || 0}</strong></div>
                        </div>

                        {/* Miembros */}
                        <div style={{ marginBottom: '16px' }}>
                            <div style={{ fontSize: '13px', fontWeight: '700', color: '#334155', marginBottom: '8px' }}>Miembros Conectados</div>
                            {(!inspectGroup.members || inspectGroup.members.length === 0) ? (
                                <div style={{ fontSize: '12px', color: '#94a3b8' }}>No hay consumidores activos en este grupo.</div>
                            ) : (
                                <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                                    {inspectGroup.members.map(m => (
                                        <div key={m.memberId} style={{ padding: '8px 12px', border: '1px solid #f1f5f9', borderRadius: '6px', fontSize: '12px', backgroundColor: '#fff' }}>
                                            <div style={{ fontWeight: '600', color: '#334155' }}>Cliente: {m.clientId} ({m.host})</div>
                                            <div style={{ color: '#64748b', fontSize: '11px', marginTop: '2px' }}>
                                                Particiones asignadas: {m.assignedPartitions?.length ? m.assignedPartitions.join(', ') : 'Ninguna'}
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </div>

                        {/* Offsets por partición */}
                        {inspectGroup.partitionOffsets && Object.keys(inspectGroup.partitionOffsets).length > 0 && (
                            <div>
                                <div style={{ fontSize: '13px', fontWeight: '700', color: '#334155', marginBottom: '8px' }}>Offsets Comprometidos</div>
                                <div style={{ backgroundColor: '#f8fafc', padding: '10px', borderRadius: '8px', fontSize: '12px', display: 'flex', flexDirection: 'column', gap: '4px' }}>
                                    {Object.entries(inspectGroup.partitionOffsets).map(([tp, off]) => (
                                        <div key={tp} style={{ display: 'flex', justifyContent: 'space-between' }}>
                                            <span>{tp}</span>
                                            <code style={{ fontWeight: '600' }}>offset: {off}</code>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}

                        <div style={{ marginTop: '20px', display: 'flex', justifyContent: 'flex-end' }}>
                            <button
                                onClick={() => setInspectGroup(null)}
                                style={{ padding: '8px 16px', borderRadius: '8px', border: '1px solid #cbd5e1', backgroundColor: '#fff', fontSize: '13px', fontWeight: '600', color: '#475569', cursor: 'pointer' }}
                            >
                                Cerrar
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
