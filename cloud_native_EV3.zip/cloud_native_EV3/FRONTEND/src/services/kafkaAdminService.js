import api from './api';

/**
 * Obtener lista de todos los tópicos de Kafka
 */
export const getKafkaTopics = async () => {
    const response = await api.get('/api/v1/notify/kafka/topics');
    return response.data;
};

/**
 * Inspeccionar detalles y configuraciones de un tópico específico
 */
export const getKafkaTopicDetails = async (topicName) => {
    const response = await api.get(`/api/v1/notify/kafka/topics/${encodeURIComponent(topicName)}`);
    return response.data;
};

/**
 * Crear un nuevo tópico Kafka con particiones, factor de replicación, retention.ms y cleanup.policy
 */
export const createKafkaTopic = async (topicData) => {
    const response = await api.post('/api/v1/notify/kafka/topics', topicData);
    return response.data;
};

/**
 * Modificar configuraciones (retention.ms, cleanup.policy) o particiones de un tópico
 */
export const updateKafkaTopic = async (topicName, updateData) => {
    const response = await api.patch(`/api/v1/notify/kafka/topics/${encodeURIComponent(topicName)}`, updateData);
    return response.data;
};

/**
 * Eliminar un tópico de Kafka
 */
export const deleteKafkaTopic = async (topicName) => {
    const response = await api.delete(`/api/v1/notify/kafka/topics/${encodeURIComponent(topicName)}`);
    return response.data;
};

/**
 * Listar todos los consumer groups de Kafka
 */
export const getKafkaConsumerGroups = async () => {
    const response = await api.get('/api/v1/notify/kafka/consumer-groups');
    return response.data;
};

/**
 * Inspeccionar miembros, estado y offsets de un consumer group
 */
export const getKafkaConsumerGroupDetails = async (groupId) => {
    const response = await api.get(`/api/v1/notify/kafka/consumer-groups/${encodeURIComponent(groupId)}`);
    return response.data;
};

/**
 * Eliminar un consumer group inactivo
 */
export const deleteKafkaConsumerGroup = async (groupId) => {
    const response = await api.delete(`/api/v1/notify/kafka/consumer-groups/${encodeURIComponent(groupId)}`);
    return response.data;
};
