tack Java Spring Boot + React, mantener RabbitMQ intacto y usar DTOs tipados.
