package cl.duoc.rutaexpress.audit.service;

import cl.duoc.rutaexpress.audit.event.ShipmentAnalyticsEvent;
import cl.duoc.rutaexpress.audit.event.ShipmentStatusEvent;
import cl.duoc.rutaexpress.audit.model.AuditLog;
import cl.duoc.rutaexpress.audit.repository.AuditRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class AuditService {

    private static final Logger log = LoggerFactory.getLogger(AuditService.class);
    private final AuditRepository auditRepository;

    public AuditService(AuditRepository auditRepository) {
        this.auditRepository = auditRepository;
    }

    @Transactional
    public AuditLog processShipmentStatusEvent(ShipmentStatusEvent event) {
        log.info("📋 Procesando evento de auditoría de envío ID: {}", event.shipmentId());

        AuditLog auditLog = new AuditLog();
        auditLog.setShipmentId(event.shipmentId());
        auditLog.setPreviousStatus(event.previousStatus());
        auditLog.setNewStatus(event.newStatus());
        auditLog.setLocation(event.location() != null ? event.location() : "Desconocida");
        auditLog.setUser(event.user() != null ? event.user() : "Sistema");
        auditLog.setTimestamp(event.timestamp() != null ? event.timestamp() : LocalDateTime.now());

        AuditLog saved = auditRepository.save(auditLog);
        log.info("💾 Registro de auditoría guardado exitosamente con ID: {} para el envío ID: {}", 
                 saved.getId(), event.shipmentId());
        return saved;
    }

    @Transactional
    public AuditLog processAnalyticsEvent(ShipmentAnalyticsEvent event) {
        log.info("📊 Procesando evento analítico para auditoría de envío ID: {}, tipo: {}", 
                 event.shipmentId(), event.eventType());

        AuditLog auditLog = new AuditLog();
        auditLog.setShipmentId(event.shipmentId());
        auditLog.setPreviousStatus(event.previousStatus());
        auditLog.setNewStatus(event.currentStatus() != null ? event.currentStatus() : event.eventType());
        auditLog.setLocation(event.location() != null ? event.location() : (event.origin() != null ? event.origin() : "Desconocida"));
        auditLog.setUser(event.user() != null ? event.user() : "Sistema");
        auditLog.setTimestamp(event.timestamp() != null ? event.timestamp() : LocalDateTime.now());

        AuditLog saved = auditRepository.save(auditLog);
        log.info("💾 Registro analítico guardado exitosamente en auditoría con ID: {} para el envío ID: {}", 
                 saved.getId(), event.shipmentId());
        return saved;
    }

    public List<AuditLog> getAllLogs() {
        return auditRepository.findAll();
    }

    public List<AuditLog> getHistoryByShipmentId(Long shipmentId) {
        return auditRepository.findByShipmentIdOrderByTimestampDesc(shipmentId);
    }
}
