package cl.duoc.rutaexpress.audit.consumer;

import cl.duoc.rutaexpress.audit.event.ShipmentAnalyticsEvent;
import cl.duoc.rutaexpress.audit.event.ShipmentStatusEvent;
import cl.duoc.rutaexpress.audit.service.AuditService;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

@Component
public class AuditKafkaConsumer {

    private static final Logger log = LoggerFactory.getLogger(AuditKafkaConsumer.class);
    private final AuditService auditService;

    public AuditKafkaConsumer(AuditService auditService) {
        this.auditService = auditService;
    }

    @KafkaListener(
        topics = "${app.kafka.topics.shipments:rutaexpress-shipments-events}",
        groupId = "${spring.kafka.consumer.group-id:audit-service-group}"
    )
    public void listenShipmentStatus(
            @Payload ShipmentStatusEvent event,
            @Header(KafkaHeaders.RECEIVED_TOPIC) String topic,
            @Header(KafkaHeaders.RECEIVED_PARTITION) int partition,
            @Header(KafkaHeaders.OFFSET) long offset) {

        log.info("📥 [Kafka Status] Evento recibido en tópico '{}' [Partición: {}, Offset: {}]: {}",
                 topic, partition, offset, event);

        // Validación de payload
        if (event == null || event.shipmentId() == null) {
            log.error("❌ [Validation Error] Evento de estado nulo o sin shipmentId en tópico '{}' [Offset: {}]", topic, offset);
            throw new IllegalArgumentException("Payload inválido: ShipmentStatusEvent requiere un shipmentId válido.");
        }

        // Delegación de lógica de negocio y persistencia al servicio de dominio
        auditService.processShipmentStatusEvent(event);
    }

    @KafkaListener(
        topics = "${app.kafka.topics.analytics:rutaexpress-analytics-events}",
        groupId = "${spring.kafka.consumer.group-id:audit-service-group}"
    )
    public void listenAnalytics(
            @Payload ShipmentAnalyticsEvent event,
            @Header(KafkaHeaders.RECEIVED_TOPIC) String topic,
            @Header(KafkaHeaders.RECEIVED_PARTITION) int partition,
            @Header(KafkaHeaders.OFFSET) long offset) {

        log.info("📥 [Kafka Analytics] Evento recibido en tópico '{}' [Partición: {}, Offset: {}]: {}",
                 topic, partition, offset, event);

        // Validación de payload
        if (event == null || event.shipmentId() == null) {
            log.error("❌ [Validation Error] Evento analítico nulo o sin shipmentId en tópico '{}' [Offset: {}]", topic, offset);
            throw new IllegalArgumentException("Payload inválido: ShipmentAnalyticsEvent requiere un shipmentId válido.");
        }

        // Delegación de lógica de negocio y persistencia al servicio de dominio
        auditService.processAnalyticsEvent(event);
    }

    @KafkaListener(
        topics = {
            "${app.kafka.topics.shipments:rutaexpress-shipments-events}-dlt",
            "${app.kafka.topics.analytics:rutaexpress-analytics-events}-dlt"
        },
        groupId = "audit-service-dlt-group"
    )
    public void listenDlt(ConsumerRecord<String, Object> record) {
        log.error("☠️ [Dead Letter Topic] Mensaje no procesable recibido en '{}' [Partición: {}, Offset: {}]. Key: {}, Payload: {}",
                 record.topic(), record.partition(), record.offset(), record.key(), record.value());
    }
}
