package cl.duoc.rutaexpress.report.consumer;

import cl.duoc.rutaexpress.report.event.ShipmentAnalyticsEvent;
import cl.duoc.rutaexpress.report.service.ReportGeneratorService;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

@Component
public class ReportKafkaConsumer {

    private static final Logger log = LoggerFactory.getLogger(ReportKafkaConsumer.class);
    private final ReportGeneratorService reportGeneratorService;

    public ReportKafkaConsumer(ReportGeneratorService reportGeneratorService) {
        this.reportGeneratorService = reportGeneratorService;
    }

    @KafkaListener(
        topics = "${app.kafka.topics.analytics:rutaexpress-analytics-events}",
        groupId = "${spring.kafka.consumer.group-id:report-analytics-group}"
    )
    public void listenAnalytics(
            @Payload ShipmentAnalyticsEvent event,
            @Header(KafkaHeaders.RECEIVED_TOPIC) String topic,
            @Header(KafkaHeaders.RECEIVED_PARTITION) int partition,
            @Header(KafkaHeaders.OFFSET) long offset) {

        log.info("📥 [Report Service Kafka] Recibido evento analítico en tópico '{}' [Partición: {}, Offset: {}]: {}",
                 topic, partition, offset, event);

        // Validación de payload
        if (event == null || event.shipmentId() == null) {
            log.error("❌ [Validation Error] Evento analítico nulo o sin shipmentId en tópico '{}' [Offset: {}]", topic, offset);
            throw new IllegalArgumentException("Payload inválido: ShipmentAnalyticsEvent requiere un shipmentId válido.");
        }

        // Delegación del procesamiento a ReportGeneratorService
        reportGeneratorService.processAnalyticsEvent(event);
    }

    @KafkaListener(
        topics = "${app.kafka.topics.analytics:rutaexpress-analytics-events}-dlt",
        groupId = "report-analytics-dlt-group"
    )
    public void listenDlt(ConsumerRecord<String, Object> record) {
        log.error("☠️ [Report DLT] Mensaje no procesable recibido en Dead Letter Topic '{}' [Partición: {}, Offset: {}]. Key: {}, Payload: {}",
                 record.topic(), record.partition(), record.offset(), record.key(), record.value());
    }
}
