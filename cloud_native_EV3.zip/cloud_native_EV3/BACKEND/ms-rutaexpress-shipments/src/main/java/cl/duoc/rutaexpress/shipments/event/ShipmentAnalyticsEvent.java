package cl.duoc.rutaexpress.shipments.event;

import java.time.LocalDateTime;

public record ShipmentAnalyticsEvent(
    Long shipmentId,
    String trackingCode,
    String eventType,
    String previousStatus,
    String currentStatus,
    String origin,
    String destination,
    String location,
    String user,
    LocalDateTime timestamp
) {}
