package cl.duoc.rutaexpress.shipments.service;

import cl.duoc.rutaexpress.shipments.config.RabbitMQConfig;
import cl.duoc.rutaexpress.shipments.dto.UpdateShipmentStatusDTO;
import cl.duoc.rutaexpress.shipments.event.ShipmentAnalyticsEvent;
import cl.duoc.rutaexpress.shipments.event.ShipmentStatusEvent;
import cl.duoc.rutaexpress.shipments.model.Shipment;
import cl.duoc.rutaexpress.shipments.producer.ShipmentKafkaProducer;
import cl.duoc.rutaexpress.shipments.repository.ShipmentRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
public class ShipmentService {

    private final ShipmentRepository shipmentRepository;
    private final RabbitTemplate rabbitTemplate;
    private final ShipmentKafkaProducer shipmentKafkaProducer;

    public ShipmentService(ShipmentRepository shipmentRepository,
                           RabbitTemplate rabbitTemplate,
                           ShipmentKafkaProducer shipmentKafkaProducer) {
        this.shipmentRepository = shipmentRepository;
        this.rabbitTemplate = rabbitTemplate;
        this.shipmentKafkaProducer = shipmentKafkaProducer;
    }

    @Transactional
    public Shipment createShipment(Shipment shipment) {
        Shipment savedShipment = shipmentRepository.save(shipment);

        LocalDateTime now = LocalDateTime.now();
        String initialLocation = savedShipment.getOrigin() != null ? savedShipment.getOrigin() : "Origen inicial";

        // Evento de estado a Kafka (rutaexpress-shipments-events)
        ShipmentStatusEvent statusEvent = new ShipmentStatusEvent(
            savedShipment.getId(),
            null,
            savedShipment.getStatus(),
            initialLocation,
            "Sistema",
            now
        );
        shipmentKafkaProducer.sendShipmentStatusEvent(statusEvent);

        // Evento analítico a Kafka (rutaexpress-analytics-events)
        ShipmentAnalyticsEvent analyticsEvent = new ShipmentAnalyticsEvent(
            savedShipment.getId(),
            savedShipment.getTrackingCode(),
            "SHIPMENT_CREATED",
            null,
            savedShipment.getStatus(),
            savedShipment.getOrigin(),
            savedShipment.getDestination(),
            initialLocation,
            "Sistema",
            now
        );
        shipmentKafkaProducer.sendShipmentAnalyticsEvent(analyticsEvent);

        return savedShipment;
    }

    @Transactional
    public Shipment updateStatus(Long id, UpdateShipmentStatusDTO dto) {
        Shipment shipment = shipmentRepository.findById(id)
            .orElseThrow(() -> new EntityNotFoundException("Envío no encontrado con ID: " + id));

        String previousStatus = shipment.getStatus();
        shipment.setStatus(dto.status());
        Shipment updatedShipment = shipmentRepository.save(shipment);

        LocalDateTime now = LocalDateTime.now();
        String location = dto.location() != null ? dto.location() : "Desconocida";
        String user = dto.user() != null ? dto.user() : "Sistema";

        // 1. Mantener intacta la publicación hacia RabbitMQ
        ShipmentStatusEvent rabbitEvent = new ShipmentStatusEvent(
            id,
            previousStatus,
            dto.status(),
            location,
            user,
            now
        );

        rabbitTemplate.convertAndSend(
            RabbitMQConfig.EXCHANGE_SHIPMENT,
            RabbitMQConfig.ROUTING_KEY_AUDIT,
            rabbitEvent
        );

        // 2. Publicación de estado a Kafka (rutaexpress-shipments-events)
        shipmentKafkaProducer.sendShipmentStatusEvent(rabbitEvent);

        // 3. Publicación de analítica a Kafka (rutaexpress-analytics-events)
        ShipmentAnalyticsEvent analyticsEvent = new ShipmentAnalyticsEvent(
            id,
            updatedShipment.getTrackingCode(),
            "STATUS_UPDATED",
            previousStatus,
            dto.status(),
            updatedShipment.getOrigin(),
            updatedShipment.getDestination(),
            location,
            user,
            now
        );
        shipmentKafkaProducer.sendShipmentAnalyticsEvent(analyticsEvent);

        return updatedShipment;
    }
}
