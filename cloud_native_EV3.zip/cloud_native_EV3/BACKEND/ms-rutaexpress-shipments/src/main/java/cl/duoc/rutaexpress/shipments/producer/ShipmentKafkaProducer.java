package cl.duoc.rutaexpress.shipments.producer;

import cl.duoc.rutaexpress.shipments.event.ShipmentAnalyticsEvent;
import cl.duoc.rutaexpress.shipments.event.ShipmentStatusEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

@Component
public class ShipmentKafkaProducer {

    private static final Logger log = LoggerFactory.getLogger(ShipmentKafkaProducer.class);

    private final KafkaTemplate<String, Object> kafkaTemplate;

    @Value("${app.kafka.topics.shipments:rutaexpress-shipments-events}")
    private String shipmentTopic;

    @Value("${app.kafka.topics.analytics:rutaexpress-analytics-events}")
    private String analyticsTopic;

    public ShipmentKafkaProducer(KafkaTemplate<String, Object> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void sendShipmentStatusEvent(ShipmentStatusEvent event) {
        log.info("⚡ Publicando evento de estado a Kafka [tópico: {}]: Envío ID {}", shipmentTopic, event.shipmentId());
        kafkaTemplate.send(shipmentTopic, String.valueOf(event.shipmentId()), event);
    }

    public void sendShipmentAnalyticsEvent(ShipmentAnalyticsEvent event) {
        log.info("📊 Publicando evento analítico a Kafka [tópico: {}]: Envío ID {}, Tipo {}", 
                 analyticsTopic, event.shipmentId(), event.eventType());
        kafkaTemplate.send(analyticsTopic, String.valueOf(event.shipmentId()), event);
    }
}
