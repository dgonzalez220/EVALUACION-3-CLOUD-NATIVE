package cl.duoc.rutaexpress.shipments;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsRutaexpressShipmentsApplicationTests {

	@Test
	void contextLoads() {
	}

}
