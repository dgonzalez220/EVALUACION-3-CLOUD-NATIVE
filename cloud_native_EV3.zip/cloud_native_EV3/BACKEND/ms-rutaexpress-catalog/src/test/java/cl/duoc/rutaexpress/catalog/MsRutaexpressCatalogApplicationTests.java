package cl.duoc.rutaexpress.catalog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsRutaexpressCatalogApplicationTests {

	@Test
	void contextLoads() {
	}

}
