package cl.duoc.rutaexpress.notify.dto;

import java.util.List;

public record KafkaPartitionDetailDTO(
    int partition,
    Integer leader,
    List<Integer> replicas,
    List<Integer> isr
) {}
