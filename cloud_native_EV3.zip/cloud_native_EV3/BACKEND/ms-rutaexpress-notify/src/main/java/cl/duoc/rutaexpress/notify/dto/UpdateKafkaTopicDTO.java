package cl.duoc.rutaexpress.notify.dto;

import jakarta.validation.constraints.Pattern;

public record UpdateKafkaTopicDTO(
    Integer partitions,
    Long retentionMs,
    @Pattern(regexp = "^(delete|compact|compact,delete|delete,compact)?$", message = "cleanup.policy debe ser 'delete', 'compact' o 'compact,delete'")
    String cleanupPolicy
) {}
