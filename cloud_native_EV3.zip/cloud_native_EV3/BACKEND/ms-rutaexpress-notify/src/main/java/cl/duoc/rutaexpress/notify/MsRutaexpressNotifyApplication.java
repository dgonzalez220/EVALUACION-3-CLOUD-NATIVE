package cl.duoc.rutaexpress.notify;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsRutaexpressNotifyApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsRutaexpressNotifyApplication.class, args);
	}

}
