package cl.duoc.rutaexpress.notify.service;

import cl.duoc.rutaexpress.notify.dto.*;
import org.apache.kafka.clients.admin.*;
import org.apache.kafka.common.Node;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.TopicPartitionInfo;
import org.apache.kafka.common.config.ConfigResource;
import org.apache.kafka.common.config.TopicConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Service
public class KafkaAdminService {

    private static final Logger log = LoggerFactory.getLogger(KafkaAdminService.class);
    private static final long TIMEOUT_SECONDS = 10;

    private final AdminClient adminClient;

    public KafkaAdminService(AdminClient adminClient) {
        this.adminClient = adminClient;
    }

    /**
     * 1. Crear tópico definiendo nombre, particiones, factor de replicación, retention.ms y cleanup.policy.
     */
    public boolean createTopic(CreateKafkaTopicDTO dto) {
        try {
            log.info("⚙️ Creando tópico Kafka: {} (Particiones: {}, Replicación: {})", 
                     dto.name(), dto.partitions(), dto.replicationFactor());

            NewTopic newTopic = new NewTopic(dto.name(), dto.partitions(), dto.replicationFactor().shortValue());
            Map<String, String> configs = new HashMap<>();

            if (dto.retentionMs() != null) {
                configs.put(TopicConfig.RETENTION_MS_CONFIG, String.valueOf(dto.retentionMs()));
            }
            if (dto.cleanupPolicy() != null && !dto.cleanupPolicy().isBlank()) {
                configs.put(TopicConfig.CLEANUP_POLICY_CONFIG, dto.cleanupPolicy());
            }

            if (!configs.isEmpty()) {
                newTopic.configs(configs);
            }

            adminClient.createTopics(Collections.singletonList(newTopic)).all().get(TIMEOUT_SECONDS, TimeUnit.SECONDS);
            log.info("✅ Tópico Kafka creado exitosamente: {}", dto.name());
            return true;
        } catch (Exception e) {
            log.error("❌ Error al crear tópico Kafka '{}': {}", dto.name(), e.getMessage(), e);
            throw new RuntimeException("Error al crear tópico Kafka: " + e.getMessage(), e);
        }
    }

    /**
     * 2. Listar tópicos (resumen).
     */
    public List<KafkaTopicSummaryDTO> listTopics() {
        try {
            ListTopicsResult result = adminClient.listTopics(new ListTopicsOptions().listInternal(true));
            Collection<TopicListing> listings = result.listings().get(TIMEOUT_SECONDS, TimeUnit.SECONDS);

            return listings.stream()
                .map(l -> new KafkaTopicSummaryDTO(l.name(), l.isInternal()))
                .sorted(Comparator.comparing(KafkaTopicSummaryDTO::name))
                .collect(Collectors.toList());
        } catch (Exception e) {
            log.error("❌ Error al listar tópicos Kafka: {}", e.getMessage(), e);
            throw new RuntimeException("Error al listar tópicos Kafka: " + e.getMessage(), e);
        }
    }

    /**
     * 2. Inspeccionar un tópico y sus configuraciones.
     */
    public KafkaTopicDetailDTO describeTopic(String topicName) {
        try {
            DescribeTopicsResult describeTopicsResult = adminClient.describeTopics(Collections.singletonList(topicName));
            TopicDescription description = describeTopicsResult.values().get(topicName).get(TIMEOUT_SECONDS, TimeUnit.SECONDS);

            // Obtener particiones y sus réplicas
            List<KafkaPartitionDetailDTO> partitionDetails = description.partitions().stream()
                .map(p -> new KafkaPartitionDetailDTO(
                    p.partition(),
                    p.leader() != null ? p.leader().id() : null,
                    p.replicas().stream().map(Node::id).collect(Collectors.toList()),
                    p.isr().stream().map(Node::id).collect(Collectors.toList())
                ))
                .sorted(Comparator.comparingInt(KafkaPartitionDetailDTO::partition))
                .collect(Collectors.toList());

            int replicationFactor = description.partitions().isEmpty() ? 0 : description.partitions().get(0).replicas().size();

            // Obtener configuraciones del tópico (retention.ms, cleanup.policy, etc.)
            ConfigResource configResource = new ConfigResource(ConfigResource.Type.TOPIC, topicName);
            DescribeConfigsResult describeConfigsResult = adminClient.describeConfigs(Collections.singletonList(configResource));
            Config config = describeConfigsResult.values().get(configResource).get(TIMEOUT_SECONDS, TimeUnit.SECONDS);

            Map<String, String> configMap = new HashMap<>();
            config.entries().forEach(entry -> {
                if (entry.value() != null) {
                    configMap.put(entry.name(), entry.value());
                }
            });

            return new KafkaTopicDetailDTO(
                topicName,
                description.partitions().size(),
                replicationFactor,
                partitionDetails,
                configMap
            );
        } catch (Exception e) {
            log.error("❌ Error al inspeccionar tópico '{}': {}", topicName, e.getMessage(), e);
            throw new RuntimeException("Error al inspeccionar tópico: " + e.getMessage(), e);
        }
    }

    /**
     * 3. Modificar configuraciones (retention.ms, cleanup.policy) y particiones de un tópico.
     */
    public boolean updateTopic(String topicName, UpdateKafkaTopicDTO dto) {
        try {
            log.info("⚙️ Modificando configuración y/o particiones del tópico: {}", topicName);

            // 1. Modificar particiones si se solicita
            if (dto.partitions() != null) {
                adminClient.createPartitions(Collections.singletonMap(
                    topicName,
                    NewPartitions.increaseTo(dto.partitions())
                )).all().get(TIMEOUT_SECONDS, TimeUnit.SECONDS);
                log.info("✅ Particiones de '{}' incrementadas a {}", topicName, dto.partitions());
            }

            // 2. Modificar configuraciones (retention.ms, cleanup.policy)
            List<AlterConfigOp> configOps = new ArrayList<>();
            if (dto.retentionMs() != null) {
                configOps.add(new AlterConfigOp(
                    new ConfigEntry(TopicConfig.RETENTION_MS_CONFIG, String.valueOf(dto.retentionMs())),
                    AlterConfigOp.OpType.SET
                ));
            }
            if (dto.cleanupPolicy() != null && !dto.cleanupPolicy().isBlank()) {
                configOps.add(new AlterConfigOp(
                    new ConfigEntry(TopicConfig.CLEANUP_POLICY_CONFIG, dto.cleanupPolicy()),
                    AlterConfigOp.OpType.SET
                ));
            }

            if (!configOps.isEmpty()) {
                ConfigResource resource = new ConfigResource(ConfigResource.Type.TOPIC, topicName);
                adminClient.incrementalAlterConfigs(Collections.singletonMap(resource, configOps))
                    .all().get(TIMEOUT_SECONDS, TimeUnit.SECONDS);
                log.info("✅ Configuraciones de '{}' actualizadas exitosamente", topicName);
            }

            return true;
        } catch (Exception e) {
            log.error("❌ Error al actualizar tópico '{}': {}", topicName, e.getMessage(), e);
            throw new RuntimeException("Error al actualizar tópico: " + e.getMessage(), e);
        }
    }

    /**
     * 4. Eliminar tópicos.
     */
    public boolean deleteTopic(String topicName) {
        try {
            log.info("🗑️ Eliminando tópico Kafka: {}", topicName);
            adminClient.deleteTopics(Collections.singletonList(topicName)).all().get(TIMEOUT_SECONDS, TimeUnit.SECONDS);
            log.info("✅ Tópico Kafka eliminado exitosamente: {}", topicName);
            return true;
        } catch (Exception e) {
            log.error("❌ Error al eliminar tópico '{}': {}", topicName, e.getMessage(), e);
            throw new RuntimeException("Error al eliminar tópico: " + e.getMessage(), e);
        }
    }

    /**
     * 5. Listar consumer-groups.
     */
    public List<KafkaConsumerGroupSummaryDTO> listConsumerGroups() {
        try {
            ListConsumerGroupsResult result = adminClient.listConsumerGroups();
            Collection<ConsumerGroupListing> listings = result.all().get(TIMEOUT_SECONDS, TimeUnit.SECONDS);

            return listings.stream()
                .map(g -> new KafkaConsumerGroupSummaryDTO(
                    g.groupId(),
                    g.isSimpleConsumerGroup(),
                    g.state().isPresent() ? g.state().get().name() : "UNKNOWN"
                ))
                .sorted(Comparator.comparing(KafkaConsumerGroupSummaryDTO::groupId))
                .collect(Collectors.toList());
        } catch (Exception e) {
            log.error("❌ Error al listar consumer groups Kafka: {}", e.getMessage(), e);
            throw new RuntimeException("Error al listar consumer groups Kafka: " + e.getMessage(), e);
        }
    }

    /**
     * 5. Inspeccionar consumer-group.
     */
    public KafkaConsumerGroupDetailDTO describeConsumerGroup(String groupId) {
        try {
            DescribeConsumerGroupsResult describeResult = adminClient.describeConsumerGroups(Collections.singletonList(groupId));
            ConsumerGroupDescription description = describeResult.describedGroups().get(groupId).get(TIMEOUT_SECONDS, TimeUnit.SECONDS);

            List<KafkaConsumerGroupMemberDTO> memberDTOs = description.members().stream()
                .map(m -> new KafkaConsumerGroupMemberDTO(
                    m.consumerId(),
                    m.clientId(),
                    m.host(),
                    m.assignment() != null && m.assignment().topicPartitions() != null ?
                        m.assignment().topicPartitions().stream()
                            .map(p -> p.topic() + "-" + p.partition())
                            .collect(Collectors.toList()) : List.of()
                ))
                .collect(Collectors.toList());

            // Offsets por partición
            Map<String, Long> partitionOffsets = new HashMap<>();
            try {
                var offsetsResult = adminClient.listConsumerGroupOffsets(groupId);
                var offsets = offsetsResult.partitionsToOffsetAndMetadata().get(TIMEOUT_SECONDS, TimeUnit.SECONDS);
                offsets.forEach((tp, om) -> {
                    partitionOffsets.put(tp.topic() + "-" + tp.partition(), om.offset());
                });
            } catch (Exception ex) {
                log.warn("⚠️ No se pudieron obtener los offsets para el grupo '{}': {}", groupId, ex.getMessage());
            }

            return new KafkaConsumerGroupDetailDTO(
                groupId,
                description.state() != null ? description.state().name() : "UNKNOWN",
                description.isSimpleConsumerGroup(),
                description.partitionAssignor(),
                description.coordinator() != null ? description.coordinator().id() : null,
                memberDTOs,
                partitionOffsets
            );
        } catch (Exception e) {
            log.error("❌ Error al inspeccionar consumer group '{}': {}", groupId, e.getMessage(), e);
            throw new RuntimeException("Error al inspeccionar consumer group: " + e.getMessage(), e);
        }
    }

    /**
     * 5. Eliminar consumer-group.
     */
    public boolean deleteConsumerGroup(String groupId) {
        try {
            log.info("🗑️ Eliminando consumer group Kafka: {}", groupId);
            adminClient.deleteConsumerGroups(Collections.singletonList(groupId)).all().get(TIMEOUT_SECONDS, TimeUnit.SECONDS);
            log.info("✅ Consumer group Kafka eliminado exitosamente: {}", groupId);
            return true;
        } catch (Exception e) {
            log.error("❌ Error al eliminar consumer group '{}': {}", groupId, e.getMessage(), e);
            throw new RuntimeException("Error al eliminar consumer group: " + e.getMessage(), e);
        }
    }
}
