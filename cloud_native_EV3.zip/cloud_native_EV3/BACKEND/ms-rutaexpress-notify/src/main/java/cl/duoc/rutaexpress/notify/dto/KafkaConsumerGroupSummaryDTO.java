package cl.duoc.rutaexpress.notify.dto;

public record KafkaConsumerGroupSummaryDTO(
    String groupId,
    boolean isSimpleConsumerGroup,
    String state
) {}
