package cl.duoc.rutaexpress.notify.dto;

import java.util.List;
import java.util.Map;

public record KafkaConsumerGroupDetailDTO(
    String groupId,
    String state,
    boolean simpleConsumerGroup,
    String partitionAssignor,
    Integer coordinatorId,
    List<KafkaConsumerGroupMemberDTO> members,
    Map<String, Long> partitionOffsets
) {}
