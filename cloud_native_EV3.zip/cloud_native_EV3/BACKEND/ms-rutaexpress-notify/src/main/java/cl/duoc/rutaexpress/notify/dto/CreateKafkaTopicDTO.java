package cl.duoc.rutaexpress.notify.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

public record CreateKafkaTopicDTO(
    @NotBlank(message = "El nombre del tópico es obligatorio")
    String name,

    @Min(value = 1, message = "Debe tener al menos 1 partición")
    Integer partitions,

    @Min(value = 1, message = "El factor de replicación debe ser al menos 1")
    Integer replicationFactor,

    Long retentionMs,

    @Pattern(regexp = "^(delete|compact|compact,delete|delete,compact)?$", message = "cleanup.policy debe ser 'delete', 'compact' o 'compact,delete'")
    String cleanupPolicy
) {
    public CreateKafkaTopicDTO {
        if (partitions == null) partitions = 1;
        if (replicationFactor == null) replicationFactor = 1;
    }
}
