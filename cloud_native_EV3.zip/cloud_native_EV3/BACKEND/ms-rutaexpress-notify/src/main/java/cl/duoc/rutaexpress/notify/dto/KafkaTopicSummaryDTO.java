package cl.duoc.rutaexpress.notify.dto;

public record KafkaTopicSummaryDTO(
    String name,
    boolean internal
) {}
