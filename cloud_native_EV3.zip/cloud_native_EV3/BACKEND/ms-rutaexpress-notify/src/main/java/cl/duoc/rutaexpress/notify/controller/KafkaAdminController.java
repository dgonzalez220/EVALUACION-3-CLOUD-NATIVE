package cl.duoc.rutaexpress.notify.controller;

import cl.duoc.rutaexpress.notify.dto.*;
import cl.duoc.rutaexpress.notify.service.KafkaAdminService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/notify/kafka")
public class KafkaAdminController {

    private final KafkaAdminService kafkaAdminService;

    public KafkaAdminController(KafkaAdminService kafkaAdminService) {
        this.kafkaAdminService = kafkaAdminService;
    }

    /**
     * Crear un nuevo tópico en Kafka
     */
    @PostMapping("/topics")
    public ResponseEntity<?> createTopic(@Valid @RequestBody CreateKafkaTopicDTO dto) {
        boolean created = kafkaAdminService.createTopic(dto);
        if (created) {
            return ResponseEntity.status(HttpStatus.CREATED)
                .body(Map.of("message", "Tópico creado exitosamente: " + dto.name()));
        }
        return ResponseEntity.badRequest().body(Map.of("error", "No se pudo crear el tópico."));
    }

    /**
     * Listar todos los tópicos de Kafka
     */
    @GetMapping("/topics")
    public ResponseEntity<List<KafkaTopicSummaryDTO>> listTopics() {
        List<KafkaTopicSummaryDTO> topics = kafkaAdminService.listTopics();
        return ResponseEntity.ok(topics);
    }

    /**
     * Inspeccionar detalles y configuraciones de un tópico
     */
    @GetMapping("/topics/{topicName}")
    public ResponseEntity<KafkaTopicDetailDTO> describeTopic(@PathVariable String topicName) {
        KafkaTopicDetailDTO detail = kafkaAdminService.describeTopic(topicName);
        return ResponseEntity.ok(detail);
    }

    /**
     * Modificar configuraciones y/o particiones de un tópico
     */
    @PatchMapping("/topics/{topicName}")
    public ResponseEntity<?> updateTopic(
            @PathVariable String topicName,
            @Valid @RequestBody UpdateKafkaTopicDTO dto) {
        boolean updated = kafkaAdminService.updateTopic(topicName, dto);
        if (updated) {
            return ResponseEntity.ok(Map.of("message", "Tópico actualizado exitosamente: " + topicName));
        }
        return ResponseEntity.badRequest().body(Map.of("error", "No se pudo actualizar el tópico."));
    }

    /**
     * Eliminar un tópico
     */
    @DeleteMapping("/topics/{topicName}")
    public ResponseEntity<?> deleteTopic(@PathVariable String topicName) {
        boolean deleted = kafkaAdminService.deleteTopic(topicName);
        if (deleted) {
            return ResponseEntity.ok(Map.of("message", "Tópico eliminado exitosamente: " + topicName));
        }
        return ResponseEntity.notFound().build();
    }

    /**
     * Listar consumer groups
     */
    @GetMapping("/consumer-groups")
    public ResponseEntity<List<KafkaConsumerGroupSummaryDTO>> listConsumerGroups() {
        List<KafkaConsumerGroupSummaryDTO> groups = kafkaAdminService.listConsumerGroups();
        return ResponseEntity.ok(groups);
    }

    /**
     * Inspeccionar consumer group
     */
    @GetMapping("/consumer-groups/{groupId}")
    public ResponseEntity<KafkaConsumerGroupDetailDTO> describeConsumerGroup(@PathVariable String groupId) {
        KafkaConsumerGroupDetailDTO detail = kafkaAdminService.describeConsumerGroup(groupId);
        return ResponseEntity.ok(detail);
    }

    /**
     * Eliminar consumer group
     */
    @DeleteMapping("/consumer-groups/{groupId}")
    public ResponseEntity<?> deleteConsumerGroup(@PathVariable String groupId) {
        boolean deleted = kafkaAdminService.deleteConsumerGroup(groupId);
        if (deleted) {
            return ResponseEntity.ok(Map.of("message", "Consumer group eliminado exitosamente: " + groupId));
        }
        return ResponseEntity.notFound().build();
    }
}
