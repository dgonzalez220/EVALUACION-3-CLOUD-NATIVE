package cl.duoc.rutaexpress.notify.dto;

import java.util.List;

public record KafkaConsumerGroupMemberDTO(
    String memberId,
    String clientId,
    String host,
    List<String> assignedPartitions
) {}
