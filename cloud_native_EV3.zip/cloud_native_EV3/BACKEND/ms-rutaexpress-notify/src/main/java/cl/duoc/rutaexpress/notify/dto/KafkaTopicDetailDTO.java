package cl.duoc.rutaexpress.notify.dto;

import java.util.List;
import java.util.Map;

public record KafkaTopicDetailDTO(
    String name,
    int partitionsCount,
    int replicationFactor,
    List<KafkaPartitionDetailDTO> partitions,
    Map<String, String> configs
) {}
